# Copyright 2026 Cloud-Dog, Viewdeck Engineering Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# cloud_dog_jobs — Confirmation polling
"""External confirmation poll tracker."""

from dataclasses import dataclass


@dataclass(slots=True)
class PollPolicy:
    """Represent poll policy."""
    interval_seconds: int = 30
    max_age_seconds: int = 3600


def should_continue_polling(age_seconds: int, policy: PollPolicy) -> bool:
    """Return whether polling should continue for given age."""
    return age_seconds <= policy.max_age_seconds
