from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import replace
from datetime import datetime, timezone

from cloud_dog_vdb.adapters.registry import AdapterRegistry
from cloud_dog_vdb.domain.models import CollectionSpec, Record, SearchRequest, SearchResponse, SearchResult
from cloud_dog_vdb.metadata.identity import compute_content_hash, compute_doc_id, compute_record_id
from cloud_dog_vdb.metadata.schema import validate_metadata
from cloud_dog_vdb.versioning.schema_version import SchemaVersionManager


class VDBClient:
    def __init__(self, registry: AdapterRegistry, default_provider_id: str) -> None:
        self._registry = registry
        self._default = default_provider_id
        self._collections: dict[str, dict[str, CollectionSpec]] = {}
        self._records: dict[str, dict[str, dict[str, Record]]] = {}
        self._schema_versions = SchemaVersionManager()

    def _adapter(self, provider_id: str | None):
        return self._registry.get(provider_id or self._default)

    def _provider(self, provider_id: str | None) -> str:
        return provider_id or self._default

    def _collection_store(self, provider_id: str) -> dict[str, CollectionSpec]:
        return self._collections.setdefault(provider_id, {})

    def _record_store(self, provider_id: str, collection: str) -> dict[str, Record]:
        backend_records = self._records.setdefault(provider_id, {})
        return backend_records.setdefault(collection, {})

    async def init_backend(self, profile: str | None = None) -> bool:
        _ = profile
        return await self._adapter(None).initialize()

    async def health_check(self, provider_id: str | None = None) -> bool:
        return await self._adapter(provider_id).health_check()

    async def create_collection(self, spec: CollectionSpec, provider_id: str | None = None) -> dict:
        out = await self._adapter(provider_id).create_collection(spec)
        pid = self._provider(provider_id)
        self._collection_store(pid)[spec.name] = spec
        self._record_store(pid, spec.name)
        self._schema_versions.register(
            spec.name,
            dimension_count=spec.embedding_dim,
            metadata_fields=list(spec.metadata_schema.keys()),
            embedding_model=str(spec.metadata.get("embedding_model", "unspecified")),
        )
        return out

    async def get_collection(self, name: str, provider_id: str | None = None) -> dict | None:
        pid = self._provider(provider_id)
        local = self._collection_store(pid).get(name)
        if local is not None:
            return {
                "name": local.name,
                "namespace": local.namespace,
                "embedding_dim": local.embedding_dim,
                "distance_metric": local.distance_metric.value,
                "metadata": dict(local.metadata),
                "metadata_schema": dict(local.metadata_schema),
                "index_params": dict(local.index_params),
                "access_policy": dict(local.access_policy),
            }
        return await self._adapter(provider_id).get_collection(name)

    async def list_collections(self, provider_id: str | None = None) -> list[dict]:
        pid = self._provider(provider_id)
        return [await self.get_collection(name, pid) for name in sorted(self._collection_store(pid))]

    async def update_collection(self, name: str, patch: dict, provider_id: str | None = None) -> dict | None:
        pid = self._provider(provider_id)
        spec = self._collection_store(pid).get(name)
        if spec is None:
            return None
        updated = replace(
            spec,
            namespace=str(patch.get("namespace", spec.namespace)),
            embedding_dim=int(patch.get("embedding_dim", spec.embedding_dim)),
            metadata={**spec.metadata, **patch.get("metadata", {})},
            metadata_schema={**spec.metadata_schema, **patch.get("metadata_schema", {})},
            index_params={**spec.index_params, **patch.get("index_params", {})},
            access_policy={**spec.access_policy, **patch.get("access_policy", {})},
        )
        self._collection_store(pid)[name] = updated
        self._schema_versions.register(
            updated.name,
            dimension_count=updated.embedding_dim,
            metadata_fields=list(updated.metadata_schema.keys()),
            embedding_model=str(updated.metadata.get("embedding_model", "unspecified")),
        )
        return await self.get_collection(name, pid)

    async def delete_collection(self, name: str, provider_id: str | None = None) -> bool:
        pid = self._provider(provider_id)
        self._collection_store(pid).pop(name, None)
        self._records.setdefault(pid, {}).pop(name, None)
        return await self._adapter(provider_id).delete_collection(name)

    def _normalise_record(self, record: Record) -> Record:
        clean_content = record.content.replace("\x00", "")
        metadata = dict(record.metadata)
        metadata.setdefault("lifecycle_state", "active")
        metadata.setdefault("is_latest", True)
        metadata.setdefault("created_at", datetime.now(tz=timezone.utc).isoformat().replace("+00:00", "Z"))
        ok, message = validate_metadata(metadata)
        if not ok:
            raise ValueError(f"invalid metadata: {message}")

        doc_id = str(metadata.get("doc_id") or compute_doc_id(str(metadata["tenant_id"]), str(metadata["source_uri"])))
        content_hash = str(metadata.get("content_hash") or compute_content_hash(clean_content))
        chunk_id = str(metadata.get("chunk_id", "0"))
        embedding_model = str(metadata.get("embedding_model", "unspecified"))
        chunker_version = str(metadata.get("chunker_version", "v1"))
        record_id = record.record_id or compute_record_id(
            doc_id, content_hash, chunk_id, embedding_model, chunker_version
        )

        metadata["doc_id"] = doc_id
        metadata["content_hash"] = content_hash
        metadata["chunk_id"] = chunk_id
        metadata["embedding_model"] = embedding_model
        metadata["chunker_version"] = chunker_version
        metadata["record_id"] = record_id
        return Record(
            record_id=record_id, content=clean_content, metadata=metadata, lifecycle_state=metadata["lifecycle_state"]
        )

    async def upsert_records(self, collection: str, records: list[Record], provider_id: str | None = None) -> list[str]:
        pid = self._provider(provider_id)
        store = self._record_store(pid, collection)
        materialised = [self._normalise_record(record) for record in records]
        incoming_doc_ids = {str(record.metadata.get("doc_id", "")) for record in materialised}
        incoming_record_ids = {record.record_id for record in materialised}

        # Supersede prior versions from earlier writes only; keep records inside
        # the current batch active so multi-chunk ingestion remains searchable.
        for existing_id, existing in list(store.items()):
            doc_id = str(existing.metadata.get("doc_id", ""))
            if not doc_id or doc_id not in incoming_doc_ids or existing_id in incoming_record_ids:
                continue
            existing_meta = dict(existing.metadata)
            existing_meta["lifecycle_state"] = "superseded"
            existing_meta["is_latest"] = False
            store[existing_id] = Record(
                record_id=existing.record_id,
                content=existing.content,
                metadata=existing_meta,
                lifecycle_state="superseded",
            )

        for normalised in materialised:
            store[normalised.record_id] = normalised
        return await self._adapter(provider_id).add_documents(
            collection,
            [r.content for r in materialised],
            [r.metadata for r in materialised],
            [r.record_id for r in materialised],
        )

    async def get_record(self, collection: str, record_id: str, provider_id: str | None = None) -> Record | None:
        pid = self._provider(provider_id)
        return self._record_store(pid, collection).get(record_id)

    async def list_records(
        self,
        collection: str,
        filters: dict | None = None,
        paging: dict | None = None,
        provider_id: str | None = None,
    ) -> list[Record]:
        pid = self._provider(provider_id)
        filters = filters or {}
        paging = paging or {}
        offset = int(paging.get("offset", 0) or 0)
        limit = int(paging.get("limit", 100) or 100)

        out: list[Record] = []
        for record in self._record_store(pid, collection).values():
            if any(record.metadata.get(k) != v for k, v in filters.items()):
                continue
            out.append(record)
        return out[offset : offset + limit]

    async def search(self, collection: str, request: SearchRequest, provider_id: str | None = None) -> SearchResponse:
        pid = self._provider(provider_id)
        expected_dim = request.query_plan_hints.get("embedding_dim")
        expected_model = request.query_plan_hints.get("embedding_model")
        self._schema_versions.warn_if_query_mismatch(
            collection,
            expected_dimension_count=int(expected_dim) if expected_dim is not None else None,
            expected_embedding_model=str(expected_model) if expected_model else None,
        )
        merged_filter = dict(request.filters)
        merged_filter.setdefault("lifecycle_state", "active")
        hits = await self._adapter(provider_id).search(
            collection,
            request.query_text or "*",
            request.top_k,
            merged_filter,
            {},
        )
        results: list[SearchResult] = []
        for hit in hits:
            score = float(hit.get("score", 0.0))
            if request.score_threshold is not None and score < request.score_threshold:
                continue
            record = self._record_store(pid, collection).get(hit["id"])
            if record and any(record.metadata.get(k) != v for k, v in merged_filter.items()):
                continue
            payload = dict(hit)
            if record:
                payload["metadata"] = dict(record.metadata)
            if not request.include_metadata:
                payload.pop("metadata", None)
            results.append(SearchResult(id=hit["id"], score=score, payload=payload))
        return SearchResponse(results=results[: request.top_k])

    async def search_stream(
        self, collection: str, request: SearchRequest, provider_id: str | None = None
    ) -> AsyncIterator[SearchResult]:
        response = await self.search(collection, request, provider_id)
        for item in response.results:
            yield item

    async def delete_record(self, collection: str, record_id: str, provider_id: str | None = None) -> bool:
        pid = self._provider(provider_id)
        current = self._record_store(pid, collection).get(record_id)
        if current is None:
            return False
        metadata = dict(current.metadata)
        metadata["lifecycle_state"] = "deleted"
        metadata["is_latest"] = False
        self._record_store(pid, collection)[record_id] = Record(
            record_id=current.record_id,
            content=current.content,
            metadata=metadata,
            lifecycle_state="deleted",
        )
        return await self._adapter(provider_id).update_document(collection, record_id, current.content, metadata)

    async def update_record(
        self,
        collection: str,
        record_id: str,
        content: str,
        metadata: dict | None = None,
        provider_id: str | None = None,
    ) -> bool:
        pid = self._provider(provider_id)
        current = self._record_store(pid, collection).get(record_id)
        if current is None:
            return False
        merged = dict(current.metadata)
        if metadata:
            merged.update(metadata)
        ok, message = validate_metadata(merged)
        if not ok:
            raise ValueError(f"invalid metadata: {message}")
        self._record_store(pid, collection)[record_id] = Record(
            record_id=record_id,
            content=content,
            metadata=merged,
            lifecycle_state=str(merged.get("lifecycle_state", "active")),
        )
        return await self._adapter(provider_id).update_document(collection, record_id, content, merged)

    async def delete_by_filter(self, collection: str, filters: dict, provider_id: str | None = None) -> int:
        pid = self._provider(provider_id)
        to_delete = [
            r.record_id
            for r in await self.list_records(
                collection,
                filters,
                paging={"offset": 0, "limit": 1_000_000},
                provider_id=pid,
            )
        ]
        count = 0
        for record_id in to_delete:
            if await self.delete_record(collection, record_id, provider_id=pid):
                count += 1
        return count

    async def count_documents(
        self,
        collection: str,
        provider_id: str | None = None,
        filter: dict | None = None,
    ) -> int:
        pid = self._provider(provider_id)
        if filter:
            return len(await self.list_records(collection, filter, provider_id=pid))
        return len(
            [r for r in self._record_store(pid, collection).values() if r.metadata.get("lifecycle_state") != "deleted"]
        )
