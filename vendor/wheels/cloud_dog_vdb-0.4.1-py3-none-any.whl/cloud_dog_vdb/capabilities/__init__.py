# cloud_dog_vdb capabilities
