from __future__ import annotations

from cloud_dog_vdb.domain.models import CapabilityDescriptor, SearchRequest


def plan_search(request: SearchRequest, capabilities: CapabilityDescriptor) -> dict:
    mode = "hybrid" if capabilities.hybrid_search else "vector"
    filters = dict(request.filters)
    if not capabilities.filtering:
        filters = {}
    top_k = max(1, min(request.top_k, capabilities.max_batch_size))
    return {"mode": mode, "top_k": top_k, "filters": filters}
