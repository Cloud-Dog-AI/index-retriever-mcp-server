from cloud_dog_vdb.domain.models import CapabilityDescriptor


def supports_hybrid(capabilities: CapabilityDescriptor) -> bool:
    return bool(capabilities.hybrid_search)


def supports_filters(capabilities: CapabilityDescriptor) -> bool:
    return bool(capabilities.filtering)


__all__ = ["CapabilityDescriptor", "supports_hybrid", "supports_filters"]
