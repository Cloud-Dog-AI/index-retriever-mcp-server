from __future__ import annotations

from dataclasses import dataclass

from cloud_dog_vdb.capabilities.planner import plan_search
from cloud_dog_vdb.domain.models import CapabilityDescriptor, SearchRequest, SearchResponse


@dataclass(frozen=True, slots=True)
class SearchPlan:
    mode: str
    top_k: int
    filters: dict


def build_search_plan(request: SearchRequest, capabilities: CapabilityDescriptor) -> SearchPlan:
    plan = plan_search(request, capabilities)
    return SearchPlan(mode=str(plan["mode"]), top_k=int(plan["top_k"]), filters=dict(plan["filters"]))


async def run_search(vdb_client, collection: str, request: SearchRequest) -> SearchResponse:
    """Execute a search request through the client.

    The runtime client already applies adapter-level planning; this helper keeps
    a stable seam for system/application flows and future instrumentation.
    """
    return await vdb_client.search(collection, request)
