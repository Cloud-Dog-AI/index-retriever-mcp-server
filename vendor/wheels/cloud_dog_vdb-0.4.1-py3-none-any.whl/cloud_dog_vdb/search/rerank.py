from __future__ import annotations

from collections.abc import Callable


def rerank(results: list[dict], key: Callable[[dict], float] | None = None, limit: int | None = None) -> list[dict]:
    """Rerank search hits using score-first ordering.

    When no key is supplied the function uses `score` descending and keeps input
    order as a tie-breaker.
    """
    rank_key = key or (lambda item: float(item.get("score", 0.0)))
    ranked = sorted(enumerate(results), key=lambda pair: (-rank_key(pair[1]), pair[0]))
    output = [item for _, item in ranked]
    return output[:limit] if isinstance(limit, int) and limit > 0 else output
