from __future__ import annotations

from cloud_dog_vdb.domain.models import CollectionSpec, Record


def sample_collection(name: str = "docs") -> CollectionSpec:
    return CollectionSpec(name=name, namespace="test", embedding_dim=4)


def sample_records() -> list[Record]:
    return [
        Record(record_id="r1", content="hello", metadata={"tenant_id": "t1", "source_uri": "file://a"}),
        Record(record_id="r2", content="world", metadata={"tenant_id": "t1", "source_uri": "file://b"}),
    ]
