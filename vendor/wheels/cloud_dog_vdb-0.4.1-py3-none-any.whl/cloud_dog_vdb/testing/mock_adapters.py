from __future__ import annotations

from cloud_dog_vdb.adapters.chroma import ChromaAdapter
from cloud_dog_vdb.config.models import ProviderConfig


def mock_adapter(provider_id: str = "chroma"):
    return ChromaAdapter(ProviderConfig(provider_id=provider_id), local_mode=True)


def mock_adapter_registry():
    from cloud_dog_vdb.adapters.registry import AdapterRegistry

    registry = AdapterRegistry()
    registry.register("chroma", mock_adapter("chroma"))
    return registry
