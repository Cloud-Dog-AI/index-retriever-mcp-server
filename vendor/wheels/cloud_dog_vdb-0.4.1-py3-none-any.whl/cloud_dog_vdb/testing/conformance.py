from __future__ import annotations


def adapter_conforms(adapter) -> bool:
    required = [
        "initialize",
        "health_check",
        "create_collection",
        "get_collection",
        "delete_collection",
        "add_documents",
        "search",
        "delete_document",
        "update_document",
        "count_documents",
    ]
    return all(hasattr(adapter, name) for name in required)
