# cloud_dog_vdb — Remote client proxy
"""Client-only remote VDB integration."""

from cloud_dog_vdb.remote.client import VDBClient

__all__ = ["VDBClient"]
