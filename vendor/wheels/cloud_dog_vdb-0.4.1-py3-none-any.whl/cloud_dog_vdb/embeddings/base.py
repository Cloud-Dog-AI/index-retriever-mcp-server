# cloud_dog_vdb — Embedding provider interface
"""Common embedding-provider contract for ingestion and search flows."""

from __future__ import annotations

from abc import ABC, abstractmethod


class EmbeddingProvider(ABC):
    """Abstract embedding provider used by ingestion/embed integration."""

    @abstractmethod
    async def embed(self, text: str) -> list[float]:
        """Return embedding vector for input text."""
