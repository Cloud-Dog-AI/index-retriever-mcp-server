from __future__ import annotations

import hashlib

from cloud_dog_vdb.metadata.normalise import normalise_source_uri


def compute_doc_id(tenant_id: str, source_uri: str) -> str:
    raw = f"{tenant_id}|{normalise_source_uri(source_uri)}".encode()
    return hashlib.sha256(raw).hexdigest()


def compute_content_hash(text: str) -> str:
    return hashlib.sha256(text.strip().encode()).hexdigest()


def compute_record_id(doc_id: str, content_hash: str, chunk_id: str, embedding_model: str, chunker_version: str) -> str:
    raw = f"{doc_id}|{content_hash}|{chunk_id}|{embedding_model}|{chunker_version}".encode()
    return hashlib.sha256(raw).hexdigest()
