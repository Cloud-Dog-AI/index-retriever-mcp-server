from __future__ import annotations

from urllib.parse import urlparse, urlunparse


def normalise_source_uri(uri: str) -> str:
    cleaned = uri.strip().lower()
    if not cleaned:
        return ""
    parsed = urlparse(cleaned)
    if parsed.scheme and parsed.netloc:
        norm = parsed._replace(
            scheme=parsed.scheme,
            netloc=parsed.netloc,
            fragment="",
        )
        return urlunparse(norm).rstrip("/")
    return cleaned.rstrip("/")
