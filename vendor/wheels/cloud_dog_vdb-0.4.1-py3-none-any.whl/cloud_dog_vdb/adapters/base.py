from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from cloud_dog_vdb.domain.models import CapabilityDescriptor, CollectionSpec


class VDBAdapter(ABC):
    @abstractmethod
    async def initialize(self, config: dict[str, Any] | None = None) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def health_check(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def create_collection(self, spec: CollectionSpec) -> dict:
        raise NotImplementedError

    @abstractmethod
    async def get_collection(self, name: str) -> dict | None:
        raise NotImplementedError

    @abstractmethod
    async def delete_collection(self, name: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def add_documents(
        self,
        collection: str,
        documents: list[str],
        metadatas: list[dict[str, Any]] | None = None,
        ids: list[str] | None = None,
    ) -> list[str]:
        raise NotImplementedError

    @abstractmethod
    async def search(
        self,
        collection: str,
        query: str,
        n_results: int,
        filter: dict[str, Any] | None = None,
        search_options: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError

    @abstractmethod
    async def delete_document(self, collection: str, doc_id: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def update_document(
        self, collection: str, doc_id: str, content: str, metadata: dict[str, Any] | None = None
    ) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def count_documents(self, collection: str, filter: dict[str, Any] | None = None) -> int:
        raise NotImplementedError

    @abstractmethod
    def capabilities(self) -> CapabilityDescriptor:
        raise NotImplementedError
