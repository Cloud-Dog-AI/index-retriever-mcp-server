from __future__ import annotations

from cloud_dog_vdb.adapters.base import VDBAdapter


class AdapterRegistry:
    def __init__(self) -> None:
        self._adapters: dict[str, VDBAdapter] = {}

    def register(self, provider_id: str, adapter: VDBAdapter) -> None:
        self._adapters[provider_id] = adapter

    def get(self, provider_id: str) -> VDBAdapter:
        if provider_id not in self._adapters:
            raise KeyError(f"Adapter not registered: {provider_id}")
        return self._adapters[provider_id]

    def list_ids(self) -> list[str]:
        return sorted(self._adapters.keys())
