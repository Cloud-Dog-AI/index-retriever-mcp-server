from cloud_dog_vdb.adapters.base import VDBAdapter
from cloud_dog_vdb.adapters.chroma import ChromaAdapter
from cloud_dog_vdb.adapters.factory import build_adapter
from cloud_dog_vdb.adapters.infinity import InfinityAdapter
from cloud_dog_vdb.adapters.opensearch import OpenSearchAdapter
from cloud_dog_vdb.adapters.qdrant import QdrantAdapter
from cloud_dog_vdb.adapters.registry import AdapterRegistry
from cloud_dog_vdb.adapters.weaviate import WeaviateAdapter

try:  # optional dependency (asyncpg)
    from cloud_dog_vdb.adapters.pgvector import PGVectorAdapter
except Exception:  # pragma: no cover
    PGVectorAdapter = None  # type: ignore[assignment]

__all__ = [
    "VDBAdapter",
    "AdapterRegistry",
    "build_adapter",
    "ChromaAdapter",
    "QdrantAdapter",
    "WeaviateAdapter",
    "OpenSearchAdapter",
    "InfinityAdapter",
    "PGVectorAdapter",
]
