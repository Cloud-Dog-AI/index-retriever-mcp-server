from __future__ import annotations

import hashlib


def deterministic_vector(text: str, dim: int) -> list[float]:
    """Build a stable pseudo-embedding from text for backend-vector operations."""
    if dim <= 0:
        raise ValueError("Vector dimension must be > 0")
    out: list[float] = []
    material = text.encode("utf-8")
    counter = 0
    while len(out) < dim:
        digest = hashlib.sha256(material + counter.to_bytes(4, "big", signed=False)).digest()
        for i in range(0, len(digest), 4):
            if len(out) >= dim:
                break
            raw = int.from_bytes(digest[i : i + 4], "big", signed=False)
            out.append((raw / 2147483648.0) - 1.0)
        counter += 1
    return out
