from __future__ import annotations

from cloud_dog_vdb.access.policy import AccessPolicy


def can_read(role: str, policy: AccessPolicy) -> bool:
    return role in policy.readers or role in policy.writers or role in policy.admins


def can_write(role: str, policy: AccessPolicy) -> bool:
    return role in policy.writers or role in policy.admins


def can_admin(role: str, policy: AccessPolicy) -> bool:
    return role in policy.admins
