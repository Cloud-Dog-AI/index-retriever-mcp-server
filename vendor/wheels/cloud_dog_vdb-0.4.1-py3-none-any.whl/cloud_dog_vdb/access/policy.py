from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class AccessPolicy:
    readers: set[str] = field(default_factory=set)
    writers: set[str] = field(default_factory=set)
    admins: set[str] = field(default_factory=set)

    def can_read(self, role: str) -> bool:
        return role in self.readers or self.can_write(role)

    def can_write(self, role: str) -> bool:
        return role in self.writers or self.can_admin(role)

    def can_admin(self, role: str) -> bool:
        return role in self.admins
