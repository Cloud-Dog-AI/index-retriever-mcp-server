from __future__ import annotations


class IsolationManager:
    """Tenant isolation helper for record filtering and namespace keys."""

    @staticmethod
    def enforce_tenant(records: list[dict], tenant_id: str) -> list[dict]:
        return [r for r in records if r.get("metadata", {}).get("tenant_id") == tenant_id]

    @staticmethod
    def namespace_for(tenant_id: str, base_namespace: str = "") -> str:
        tenant = tenant_id.strip()
        base = base_namespace.strip()
        return f"{base}:{tenant}" if base else tenant


def enforce_tenant(records: list[dict], tenant_id: str) -> list[dict]:
    """Compatibility wrapper for existing imports."""
    return IsolationManager.enforce_tenant(records, tenant_id)
