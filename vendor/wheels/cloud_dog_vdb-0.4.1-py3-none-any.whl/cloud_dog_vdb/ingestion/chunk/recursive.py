from __future__ import annotations

from cloud_dog_vdb.ingestion.chunk.base import Chunker


class RecursiveChunker(Chunker):
    def __init__(self, max_chars: int = 500) -> None:
        self._max_chars = max_chars

    def chunk(self, text: str) -> list[str]:
        parts = [p.strip() for p in text.split("\n\n") if p.strip()]
        if len(parts) <= 1:
            if len(text) <= self._max_chars:
                return [text]
            return [text[i : i + self._max_chars] for i in range(0, len(text), self._max_chars)]
        return parts
