from __future__ import annotations


DO_NOT_SPLIT_MARKERS = ("```", "<table", "|---|")


def contains_do_not_split_marker(text: str) -> bool:
    return any(marker in text for marker in DO_NOT_SPLIT_MARKERS)
