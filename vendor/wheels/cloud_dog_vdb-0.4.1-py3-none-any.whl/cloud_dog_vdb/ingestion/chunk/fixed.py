from __future__ import annotations

from cloud_dog_vdb.ingestion.chunk.base import Chunker


class FixedChunker(Chunker):
    def __init__(self, size: int = 100) -> None:
        self.size = size

    def chunk(self, text: str) -> list[str]:
        return [text[i : i + self.size] for i in range(0, len(text), self.size)] or [""]
