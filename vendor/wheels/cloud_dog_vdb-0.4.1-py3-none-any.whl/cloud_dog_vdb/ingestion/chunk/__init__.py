# cloud_dog_vdb ingestion/chunk
