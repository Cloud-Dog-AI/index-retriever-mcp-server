from __future__ import annotations

from abc import ABC, abstractmethod


class Chunker(ABC):
    @abstractmethod
    def chunk(self, text: str) -> list[str]:
        raise NotImplementedError

    def _clean(self, chunks: list[str]) -> list[str]:
        return [chunk.strip() for chunk in chunks if chunk and chunk.strip()]

    def chunk_non_empty(self, text: str) -> list[str]:
        return self._clean(self.chunk(text))
