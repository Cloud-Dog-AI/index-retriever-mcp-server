from __future__ import annotations

from cloud_dog_vdb.ingestion.chunk.base import Chunker


class SemanticChunker(Chunker):
    def __init__(self, min_sentence_len: int = 0) -> None:
        self._min_sentence_len = min_sentence_len

    def chunk(self, text: str) -> list[str]:
        sentences = [s.strip() for s in text.replace("\n", " ").split(".") if s.strip()]
        out: list[str] = []
        acc = ""
        for sentence in sentences:
            candidate = f"{acc}. {sentence}".strip(". ") if acc else sentence
            if len(candidate) < self._min_sentence_len:
                acc = candidate
                continue
            out.append(candidate)
            acc = ""
        if acc:
            out.append(acc)
        return out or [text]
