from __future__ import annotations

from cloud_dog_vdb.ingestion.ocr.base import OCRProvider


class OCRRegistry:
    def __init__(self) -> None:
        self._providers: dict[str, OCRProvider] = {}

    def register(self, provider: OCRProvider) -> None:
        self._providers[provider.provider_id] = provider

    def get(self, provider_id: str) -> OCRProvider | None:
        return self._providers.get(provider_id)

    def list_ids(self) -> list[str]:
        return sorted(self._providers)
