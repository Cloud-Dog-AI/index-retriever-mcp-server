from cloud_dog_vdb.ingestion.ocr.base import OCRDecision, OCRProvider
from cloud_dog_vdb.ingestion.ocr.heuristics import should_use_ocr_auto
from cloud_dog_vdb.ingestion.ocr.planner import decide_ocr
from cloud_dog_vdb.ingestion.ocr.registry import OCRRegistry

__all__ = [
    "OCRDecision",
    "OCRProvider",
    "OCRRegistry",
    "should_use_ocr_auto",
    "decide_ocr",
]
