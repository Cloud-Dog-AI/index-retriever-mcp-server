from __future__ import annotations


def should_use_ocr_auto(
    *,
    text_chars: int,
    scanned_ratio: float,
    min_chars: int = 200,
    min_scanned_ratio: float = 0.5,
) -> bool:
    return int(text_chars) < int(min_chars) and float(scanned_ratio) >= float(min_scanned_ratio)


def ocr_cost_within_budget(*, estimated_cost: float, max_cost_per_document: float) -> bool:
    return float(estimated_cost) <= float(max_cost_per_document)
