from __future__ import annotations

from cloud_dog_vdb.ingestion.parse.ir import TableBlock


def table_json_payload(table: TableBlock, *, shape: str = "records") -> dict:
    if shape == "rows_cols":
        return {
            "headers": list(table.headers),
            "rows": [list(row) for row in table.rows],
            "page": table.page,
            "locator": table.locator,
        }
    records: list[dict[str, str]] = []
    for row in table.rows:
        row_dict: dict[str, str] = {}
        for index, value in enumerate(row):
            key = table.headers[index] if index < len(table.headers) and table.headers[index] else f"col_{index}"
            row_dict[key] = value
        records.append(row_dict)
    return {
        "records": records,
        "page": table.page,
        "locator": table.locator,
    }
