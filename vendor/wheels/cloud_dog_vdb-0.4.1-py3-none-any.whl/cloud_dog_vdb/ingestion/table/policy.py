from __future__ import annotations

SUPPORTED_TABLE_POLICIES = {
    "table_as_text",
    "table_as_markdown",
    "table_as_html",
    "table_as_json",
    "table_dual",
}


def normalise_table_policy(policy: str) -> str:
    value = str(policy or "table_as_markdown").strip().lower()
    if value not in SUPPORTED_TABLE_POLICIES:
        return "table_as_markdown"
    return value
