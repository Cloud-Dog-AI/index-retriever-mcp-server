from __future__ import annotations

from cloud_dog_vdb.ingestion.convert.base import Converter


class PandasConverter(Converter):
    """Simple tabular normaliser used in tests and fallback mode."""

    def convert(self, source: str) -> str:
        lines = [line.strip() for line in source.splitlines() if line.strip()]
        if not lines:
            return ""
        header = lines[0]
        rows = lines[1:]
        if not rows:
            return header
        return "\n".join([header] + rows)
