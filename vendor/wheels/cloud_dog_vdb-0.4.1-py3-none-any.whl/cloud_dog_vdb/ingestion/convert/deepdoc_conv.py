from __future__ import annotations

from cloud_dog_vdb.ingestion.convert.base import Converter


class DeepDocConverter(Converter):
    """Fallback document extractor that preserves paragraph layout."""

    def convert(self, source: str) -> str:
        paragraphs = [p.strip() for p in source.split("\n\n") if p.strip()]
        return "\n\n".join(paragraphs)
