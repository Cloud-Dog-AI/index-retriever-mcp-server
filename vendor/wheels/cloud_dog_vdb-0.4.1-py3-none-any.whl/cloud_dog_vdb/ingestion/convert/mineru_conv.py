from __future__ import annotations

from cloud_dog_vdb.ingestion.convert.base import Converter


class MineruConverter(Converter):
    """Fallback extraction normaliser for MinerU-like output."""

    def convert(self, source: str) -> str:
        return " ".join(source.split())
