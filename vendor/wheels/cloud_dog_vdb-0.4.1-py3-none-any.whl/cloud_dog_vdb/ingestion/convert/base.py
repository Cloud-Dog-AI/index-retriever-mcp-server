from __future__ import annotations

from abc import ABC, abstractmethod


class Converter(ABC):
    @abstractmethod
    def convert(self, source: str) -> str:
        raise NotImplementedError


class NoOpConverter(Converter):
    def convert(self, source: str) -> str:
        return source
