from __future__ import annotations

from cloud_dog_vdb.embeddings.base import EmbeddingProvider


async def embed_text(provider: EmbeddingProvider, text: str) -> list[float]:
    return await provider.embed(text)


async def embed_chunks(provider: EmbeddingProvider, chunks: list[str]) -> list[list[float]]:
    vectors: list[list[float]] = []
    for chunk in chunks:
        vectors.append(await embed_text(provider, chunk))
    return vectors
