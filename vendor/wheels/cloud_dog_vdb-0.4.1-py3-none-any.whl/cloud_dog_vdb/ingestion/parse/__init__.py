from cloud_dog_vdb.ingestion.parse.base import ParserProvider
from cloud_dog_vdb.ingestion.parse.capabilities import ParserCapabilities
from cloud_dog_vdb.ingestion.parse.ir import DocumentIR, TableBlock, TextBlock
from cloud_dog_vdb.ingestion.parse.planner import build_fallback_chain, pick_first_available
from cloud_dog_vdb.ingestion.parse.providers.deepdoc import DeepDocParserProvider
from cloud_dog_vdb.ingestion.parse.providers.docling import DoclingParserProvider
from cloud_dog_vdb.ingestion.parse.providers.internal import InternalParserProvider
from cloud_dog_vdb.ingestion.parse.providers.marker_mcp import MarkerMcpParserProvider
from cloud_dog_vdb.ingestion.parse.providers.mineru import MineruParserProvider
from cloud_dog_vdb.ingestion.parse.providers.transformers import TransformersParserProvider
from cloud_dog_vdb.ingestion.parse.quality import quality_gate_passed
from cloud_dog_vdb.ingestion.parse.registry import ParserRegistry

__all__ = [
    "ParserProvider",
    "ParserCapabilities",
    "DocumentIR",
    "TextBlock",
    "TableBlock",
    "ParserRegistry",
    "pick_first_available",
    "build_fallback_chain",
    "quality_gate_passed",
    "InternalParserProvider",
    "MineruParserProvider",
    "MarkerMcpParserProvider",
    "DeepDocParserProvider",
    "DoclingParserProvider",
    "TransformersParserProvider",
]
