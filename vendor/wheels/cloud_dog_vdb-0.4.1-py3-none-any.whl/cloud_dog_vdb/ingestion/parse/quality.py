from __future__ import annotations


def quality_gate_passed(quality: dict[str, float], *, min_confidence: float = 0.0) -> bool:
    confidence = float(quality.get("confidence", 1.0))
    return confidence >= min_confidence
