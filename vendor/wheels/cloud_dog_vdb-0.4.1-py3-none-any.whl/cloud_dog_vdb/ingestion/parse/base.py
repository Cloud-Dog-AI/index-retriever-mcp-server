from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from cloud_dog_vdb.ingestion.parse.capabilities import ParserCapabilities
from cloud_dog_vdb.ingestion.parse.ir import DocumentIR


class ParserProvider(ABC):
    provider_id: str
    provider_version: str

    @property
    @abstractmethod
    def capabilities(self) -> ParserCapabilities:
        raise NotImplementedError

    @abstractmethod
    async def health_check(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    async def parse_bytes(
        self,
        document: bytes,
        *,
        filename: str,
        source_uri: str,
        mime_type: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> DocumentIR:
        raise NotImplementedError
