from __future__ import annotations

import asyncio
import io
from typing import Any

import httpx

from cloud_dog_vdb.domain.errors import BackendUnavailableError, InvalidRequestError
from cloud_dog_vdb.ingestion.parse.base import ParserProvider
from cloud_dog_vdb.ingestion.parse.capabilities import ParserCapabilities
from cloud_dog_vdb.ingestion.parse.ir import DocumentIR, TextBlock
from cloud_dog_vdb.ingestion.parse.providers.internal import _decode_best_effort, _to_text_blocks


def _coerce_mineru_text(body: dict[str, Any]) -> str:
    if isinstance(body.get("text"), str):
        return str(body["text"])
    if isinstance(body.get("markdown"), str):
        return str(body["markdown"])
    results = body.get("results")
    if isinstance(results, dict) and results:
        first = next(iter(results.values()))
        if isinstance(first, dict):
            for key in ("md_content", "markdown", "text", "content"):
                value = first.get(key)
                if isinstance(value, str) and value.strip():
                    return value
    for key in ("content", "output"):
        value = body.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return ""


def _parse_bool(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if not text:
        return default
    return text in {"1", "true", "yes", "on"}


def _parse_int(value: Any, *, default: int, minimum: int = 0) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(parsed, minimum)


def _looks_like_oom(message: str) -> bool:
    text = message.lower()
    return "cuda out of memory" in text or "out of memory" in text


def _looks_like_timeout(message: str) -> bool:
    text = message.lower()
    return "readtimeout" in text or "connecttimeout" in text or "timed out" in text


def _supports_page_fallback(filename: str, mime_type: str | None) -> bool:
    name = filename.lower()
    if name.endswith(".pdf"):
        return True
    return str(mime_type or "").lower().strip() == "application/pdf"


def _pdf_page_count(document: bytes) -> int | None:
    try:
        from pypdf import PdfReader
    except Exception:
        return None
    try:
        reader = PdfReader(io.BytesIO(document))
        return len(reader.pages)
    except Exception:
        return None


class MineruParserProvider(ParserProvider):
    provider_id = "mineru"
    provider_version = "api-0.1.0"

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str = "",
        timeout_seconds: float = 120.0,
        parse_backend: str = "pipeline",
        parse_method: str = "txt",
        request_retries: int = 3,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.parse_backend = parse_backend
        self.parse_method = parse_method
        self.request_retries = max(int(request_retries), 1)
        self._client = httpx.AsyncClient(timeout=timeout_seconds)

    @property
    def capabilities(self) -> ParserCapabilities:
        return ParserCapabilities(
            supports_pdf=True,
            supports_docx=True,
            supports_html=True,
            supports_layout=True,
            supports_tables=True,
            supports_images=True,
            supports_ocr_passthrough=True,
            supports_streaming=False,
            max_document_bytes=256 * 1024 * 1024,
        )

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    async def _request_parse(
        self,
        *,
        document: bytes,
        filename: str,
        mime_type: str | None,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        files = {"files": (filename, document, mime_type or "application/octet-stream")}
        retries = self.request_retries
        resp: httpx.Response | None = None
        for attempt in range(retries):
            try:
                resp = await self._client.post(
                    f"{self.base_url}/file_parse",
                    headers=self._headers(),
                    data=payload,
                    files=files,
                )
            except httpx.HTTPError as exc:
                if attempt + 1 < retries:
                    await asyncio.sleep(0.5 * (attempt + 1))
                    continue
                raise InvalidRequestError(f"mineru parse request failed: {type(exc).__name__}: {exc}") from exc

            if resp.status_code >= 500 and attempt + 1 < retries:
                await asyncio.sleep(0.5 * (attempt + 1))
                continue
            break

        if resp is None:
            raise InvalidRequestError("mineru parse request failed: no response")
        if resp.status_code >= 400:
            raise InvalidRequestError(f"mineru parse failed: {resp.status_code} {resp.text[:300]}")
        try:
            out = resp.json()
        except Exception as exc:
            raise InvalidRequestError(f"mineru parse returned non-json response: {exc}") from exc
        return out

    @staticmethod
    def _extract_request_payload(
        parse_backend: str,
        parse_method: str,
        options: dict[str, Any],
    ) -> dict[str, Any]:
        allowed_keys = (
            "output_dir",
            "lang_list",
            "formula_enable",
            "table_enable",
            "server_url",
            "return_md",
            "return_middle_json",
            "return_model_output",
            "return_content_list",
            "return_images",
            "response_format_zip",
            "start_page_id",
            "end_page_id",
        )
        payload: dict[str, Any] = {"backend": parse_backend, "parse_method": parse_method}
        for key in allowed_keys:
            value = options.get(key)
            if value is None:
                continue
            payload[key] = value
        return payload

    @staticmethod
    def _adaptive_payloads(base_payload: dict[str, Any]) -> list[dict[str, Any]]:
        base = dict(base_payload)
        out = [base]

        low_vram = dict(base)
        low_vram["formula_enable"] = False
        low_vram["table_enable"] = False
        low_vram["return_middle_json"] = False
        low_vram["return_images"] = False
        if low_vram not in out:
            out.append(low_vram)

        for backend, method in (
            ("pipeline", "auto"),
            ("pipeline", "ocr"),
            ("vlm-auto-engine", "auto"),
            ("hybrid-auto-engine", "auto"),
        ):
            candidate = dict(low_vram)
            candidate["backend"] = backend
            candidate["parse_method"] = method
            if candidate not in out:
                out.append(candidate)
        return out

    async def _parse_pages(
        self,
        *,
        document: bytes,
        filename: str,
        source_uri: str,
        mime_type: str | None,
        payload_candidates: list[dict[str, Any]],
        target_chars: int,
        max_pages: int,
    ) -> DocumentIR:
        page_count = _pdf_page_count(document)
        if page_count is None or page_count <= 0:
            raise InvalidRequestError("mineru page fallback unavailable: unable to determine PDF page count")

        upper_bound = page_count if max_pages <= 0 else min(page_count, max_pages)
        pieces: list[str] = []
        errors: list[str] = []
        parsed_pages: list[int] = []

        for page_index in range(upper_bound):
            page_success = False
            for payload in payload_candidates[:2]:
                page_payload = dict(payload)
                page_payload["start_page_id"] = page_index
                page_payload["end_page_id"] = page_index
                try:
                    response = await self._request_parse(
                        document=document,
                        filename=filename,
                        mime_type=mime_type,
                        payload=page_payload,
                    )
                    text = _coerce_mineru_text(response).strip()
                    if text:
                        pieces.append(text)
                    parsed_pages.append(page_index)
                    page_success = True
                    break
                except InvalidRequestError as exc:
                    errors.append(f"page={page_index}:{exc}")
            if target_chars > 0 and len("\n\n".join(pieces)) >= target_chars:
                break
            if not page_success and page_index > 0 and not pieces:
                break

        text = "\n\n".join(piece for piece in pieces if piece.strip()).strip()
        if not text:
            detail = errors[0] if errors else "unknown error"
            raise InvalidRequestError(f"mineru page fallback failed: {detail}")

        return DocumentIR(
            source_uri=source_uri,
            provider_id=self.provider_id,
            provider_version=self.provider_version,
            text_blocks=_to_text_blocks(text) or [TextBlock(text=text)],
            quality={"confidence": 0.86},
            metadata={
                "page_fallback": True,
                "parsed_page_count": len(parsed_pages),
                "target_chars": target_chars,
                "max_pages": max_pages,
            },
        )

    async def health_check(self) -> bool:
        probe_paths = ("/openapi.json", "/docs", "/")
        for path in probe_paths:
            for _ in range(2):
                try:
                    resp = await self._client.get(f"{self.base_url}{path}", headers=self._headers())
                    if resp.status_code < 500:
                        return True
                except Exception:
                    continue
        return False

    async def parse_bytes(
        self,
        document: bytes,
        *,
        filename: str,
        source_uri: str,
        mime_type: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> DocumentIR:
        if not self.base_url:
            raise BackendUnavailableError("mineru base_url is not configured")

        opts = dict(options or {})
        parse_backend = str(opts.get("parse_backend", self.parse_backend))
        parse_method = str(opts.get("parse_method", self.parse_method))
        page_fallback_enabled = _parse_bool(opts.get("page_fallback_enabled"), default=True)
        page_fallback_target_chars = _parse_int(
            opts.get("page_fallback_target_chars", opts.get("target_chars", 3200)),
            default=3200,
            minimum=0,
        )
        page_fallback_max_pages = _parse_int(opts.get("page_fallback_max_pages", 24), default=24, minimum=1)

        base_payload = self._extract_request_payload(parse_backend, parse_method, opts)
        payload_candidates = self._adaptive_payloads(base_payload)
        errors: list[str] = []
        resource_limited_failure = False

        for payload in payload_candidates:
            try:
                response = await self._request_parse(
                    document=document,
                    filename=filename,
                    mime_type=mime_type,
                    payload=payload,
                )
                text = _coerce_mineru_text(response).strip()
                if not text:
                    text = _decode_best_effort(document).strip()
                return DocumentIR(
                    source_uri=source_uri,
                    provider_id=self.provider_id,
                    provider_version=self.provider_version,
                    text_blocks=_to_text_blocks(text) or [TextBlock(text=text)],
                    quality={"confidence": 0.9},
                    metadata={"backend": payload.get("backend"), "parse_method": payload.get("parse_method")},
                )
            except InvalidRequestError as exc:
                message = str(exc)
                errors.append(message)
                if _looks_like_oom(message) or _looks_like_timeout(message):
                    resource_limited_failure = True
                    break

        if page_fallback_enabled and _supports_page_fallback(filename, mime_type):
            return await self._parse_pages(
                document=document,
                filename=filename,
                source_uri=source_uri,
                mime_type=mime_type,
                payload_candidates=payload_candidates,
                target_chars=page_fallback_target_chars,
                max_pages=page_fallback_max_pages,
            )

        if resource_limited_failure:
            detail = errors[-1] if errors else "resource-limited parser failure"
            raise InvalidRequestError(f"mineru parse failed due resource constraints: {detail}")
        detail = errors[-1] if errors else "unknown error"
        raise InvalidRequestError(f"mineru parse failed after adaptive retries: {detail}")
