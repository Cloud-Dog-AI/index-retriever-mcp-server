from __future__ import annotations

from typing import Any

import httpx

from cloud_dog_vdb.domain.errors import BackendUnavailableError, InvalidRequestError
from cloud_dog_vdb.ingestion.parse.base import ParserProvider
from cloud_dog_vdb.ingestion.parse.capabilities import ParserCapabilities
from cloud_dog_vdb.ingestion.parse.ir import DocumentIR
from cloud_dog_vdb.ingestion.parse.providers.internal import _decode_best_effort, _to_text_blocks


def _coerce_marker_text(payload: dict[str, Any]) -> str:
    for key in ("markdown", "text", "content"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value
    result = payload.get("result")
    if isinstance(result, dict):
        for key in ("markdown", "text", "content"):
            value = result.get(key)
            if isinstance(value, str) and value.strip():
                return value
    return ""


class MarkerMcpParserProvider(ParserProvider):
    provider_id = "marker_mcp"
    provider_version = "api-0.1.0"

    def __init__(self, *, base_url: str, auth_token: str = "", timeout_seconds: float = 120.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.auth_token = auth_token
        self._client = httpx.AsyncClient(timeout=timeout_seconds)

    @property
    def capabilities(self) -> ParserCapabilities:
        return ParserCapabilities(
            supports_pdf=True,
            supports_docx=True,
            supports_html=True,
            supports_layout=True,
            supports_tables=True,
            supports_images=True,
            supports_ocr_passthrough=True,
            supports_streaming=False,
            max_document_bytes=128 * 1024 * 1024,
        )

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        return headers

    async def health_check(self) -> bool:
        try:
            resp = await self._client.get(f"{self.base_url}/openapi.json", headers=self._headers())
            return resp.status_code == 200
        except Exception:
            return False

    async def parse_bytes(
        self,
        document: bytes,
        *,
        filename: str,
        source_uri: str,
        mime_type: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> DocumentIR:
        _ = options
        if not self.base_url:
            raise BackendUnavailableError("marker_mcp base_url is not configured")
        files = {"file": (filename, document, mime_type or "application/octet-stream")}
        resp = await self._client.post(
            f"{self.base_url}/marker/upload",
            headers=self._headers(),
            files=files,
        )
        if resp.status_code >= 400:
            raise InvalidRequestError(f"marker_mcp parse failed: {resp.status_code} {resp.text[:200]}")
        payload = resp.json()
        if payload.get("success") is False:
            raise InvalidRequestError(f"marker_mcp parse failed: {payload.get('error', 'unknown_error')}")
        text = _coerce_marker_text(payload).strip()
        if not text:
            text = _decode_best_effort(document).strip()
        return DocumentIR(
            source_uri=source_uri,
            provider_id=self.provider_id,
            provider_version=self.provider_version,
            text_blocks=_to_text_blocks(text),
            quality={"confidence": 0.85},
        )
