from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ParserCapabilities:
    supports_pdf: bool = True
    supports_docx: bool = False
    supports_html: bool = False
    supports_layout: bool = False
    supports_tables: bool = False
    supports_images: bool = False
    supports_ocr_passthrough: bool = False
    supports_streaming: bool = False
    max_document_bytes: int = 64 * 1024 * 1024
