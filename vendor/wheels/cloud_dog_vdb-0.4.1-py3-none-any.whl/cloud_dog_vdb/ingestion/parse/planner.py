from __future__ import annotations

from cloud_dog_vdb.ingestion.parse.registry import ParserRegistry


def pick_first_available(chain: list[str], registry: ParserRegistry) -> str | None:
    available = set(registry.list_ids())
    for provider_id in chain:
        if provider_id in available:
            return provider_id
    return None


def build_fallback_chain(chain: list[str], failed_provider: str) -> list[str]:
    return [provider_id for provider_id in chain if provider_id != failed_provider]
