from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class TextBlock:
    text: str
    kind: str = "paragraph"
    page: int | None = None
    section_path: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class TableBlock:
    headers: list[str] = field(default_factory=list)
    rows: list[list[str]] = field(default_factory=list)
    page: int | None = None
    locator: str = ""


@dataclass(frozen=True, slots=True)
class DocumentIR:
    source_uri: str
    provider_id: str
    provider_version: str
    text_blocks: list[TextBlock] = field(default_factory=list)
    table_blocks: list[TableBlock] = field(default_factory=list)
    artefacts: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    quality: dict[str, float] = field(default_factory=dict)

    def full_text(self) -> str:
        return "\n\n".join(block.text.strip() for block in self.text_blocks if block.text.strip())
