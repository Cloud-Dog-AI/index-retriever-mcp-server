from __future__ import annotations

from cloud_dog_vdb.ingestion.parse.base import ParserProvider


class ParserRegistry:
    def __init__(self) -> None:
        self._providers: dict[str, ParserProvider] = {}

    def register(self, provider: ParserProvider) -> None:
        self._providers[provider.provider_id] = provider

    def get(self, provider_id: str) -> ParserProvider | None:
        return self._providers.get(provider_id)

    def list_ids(self) -> list[str]:
        return sorted(self._providers)
