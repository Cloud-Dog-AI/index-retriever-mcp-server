from __future__ import annotations


def verify_ids(ids: list[str]) -> bool:
    if not ids:
        return False
    clean = [i for i in ids if isinstance(i, str) and i.strip()]
    if len(clean) != len(ids):
        return False
    return len(set(clean)) == len(clean)


def verify_minimum(ids: list[str], expected_min: int) -> bool:
    return verify_ids(ids) and len(ids) >= max(0, expected_min)
