from __future__ import annotations

from pathlib import Path


def acquire_text(source: str) -> str:
    """Acquire text from inline content or filesystem path."""
    path = Path(source)
    if path.exists() and path.is_file():
        return path.read_text(encoding="utf-8")
    return source


def acquire_bytes(source: bytes | str) -> tuple[bytes, str]:
    if isinstance(source, bytes):
        return source, "document.bin"
    path = Path(source)
    if path.exists() and path.is_file():
        return path.read_bytes(), path.name
    return source.encode("utf-8"), "inline.txt"
