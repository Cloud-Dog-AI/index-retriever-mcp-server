from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass(frozen=True, slots=True)
class Checkpoint:
    stage: str
    count: int
    created_at: str


def checkpoint(stage: str, count: int) -> dict:
    point = Checkpoint(stage=stage, count=int(count), created_at=datetime.now(tz=timezone.utc).isoformat())
    # Keep legacy return contract used by tests and callers.
    return {"stage": point.stage, "count": point.count}
