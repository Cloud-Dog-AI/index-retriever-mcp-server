from __future__ import annotations

from cloud_dog_vdb.domain.models import (
    CapabilityDescriptor,
    CollectionSpec,
    Job,
    Record,
    SearchRequest,
    SearchResponse,
    SearchResult,
)
from cloud_dog_vdb.factory import get_vdb_client
from cloud_dog_vdb.ingestion.pipeline import IngestionPipeline, ParserIngestionOptions, ingest_document
from cloud_dog_vdb.runtime.client import VDBClient

__version__ = "0.4.1"

__all__ = [
    "VDBClient",
    "CapabilityDescriptor",
    "CollectionSpec",
    "Record",
    "SearchRequest",
    "SearchResult",
    "SearchResponse",
    "Job",
    "get_vdb_client",
    "ingest_document",
    "ParserIngestionOptions",
    "IngestionPipeline",
]
