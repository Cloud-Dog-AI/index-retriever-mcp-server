from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ProviderConfig:
    provider_id: str
    base_url: str = ""
    api_key: str = ""
    username: str = ""
    password: str = ""
    host: str = ""
    port: int = 0
    database: str = ""
    database_uri: str = ""
    timeout_seconds: float = 30.0
