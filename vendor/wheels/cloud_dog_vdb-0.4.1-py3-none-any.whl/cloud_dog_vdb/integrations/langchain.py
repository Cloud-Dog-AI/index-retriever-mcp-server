from __future__ import annotations

from typing import Any


def to_langchain_document(record: dict) -> dict:
    return {
        "page_content": record.get("content", ""),
        "metadata": dict(record.get("metadata", {})),
    }


def from_langchain_document(document: Any) -> dict:
    page_content = getattr(document, "page_content", "")
    metadata = getattr(document, "metadata", {}) or {}
    return {"content": str(page_content), "metadata": dict(metadata)}
