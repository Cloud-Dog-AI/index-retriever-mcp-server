from __future__ import annotations

from typing import Any


def to_llamaindex_record(record: dict) -> dict:
    return {
        "text": record.get("content", ""),
        "metadata": dict(record.get("metadata", {})),
    }


def from_llamaindex_node(node: Any) -> dict:
    text = getattr(node, "text", "")
    metadata = getattr(node, "metadata", {}) or {}
    return {"content": str(text), "metadata": dict(metadata)}
