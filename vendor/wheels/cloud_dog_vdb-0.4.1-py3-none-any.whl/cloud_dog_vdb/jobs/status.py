from __future__ import annotations


def progress(done: int, total: int) -> float:
    if total <= 0:
        return 0.0
    return max(0.0, min(1.0, done / total))


def status_from_progress(done: int, total: int) -> str:
    ratio = progress(done, total)
    if ratio <= 0.0:
        return "queued"
    if ratio >= 1.0:
        return "completed"
    return "running"
