from __future__ import annotations

from cloud_dog_vdb.domain.models import Job


class JobQueue:
    def __init__(self) -> None:
        self._jobs: dict[str, Job] = {}

    async def submit(self, job: Job) -> str:
        self._jobs[job.job_id] = job
        return job.job_id

    async def get(self, job_id: str) -> Job | None:
        return self._jobs.get(job_id)

    async def list(self) -> list[Job]:
        return list(self._jobs.values())

    async def cancel(self, job_id: str) -> bool:
        if job_id not in self._jobs:
            return False
        j = self._jobs[job_id]
        self._jobs[job_id] = Job(**{**j.__dict__, "status": "cancelled"})
        return True
