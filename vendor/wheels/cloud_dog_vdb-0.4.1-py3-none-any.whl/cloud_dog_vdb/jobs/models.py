from cloud_dog_vdb.domain.models import Job


def is_terminal(job: Job) -> bool:
    return job.status in {"completed", "failed", "cancelled"}


def is_running(job: Job) -> bool:
    return job.status == "running"


__all__ = ["Job", "is_terminal", "is_running"]
