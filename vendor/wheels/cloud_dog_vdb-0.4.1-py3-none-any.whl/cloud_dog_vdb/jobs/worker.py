from __future__ import annotations

from cloud_dog_vdb.jobs.models import is_terminal


async def run_once(queue, handler) -> bool:
    """Process a single non-terminal job if available."""
    jobs = await queue.list()
    for job in jobs:
        if is_terminal(job):
            continue
        await handler(job)
        return True
    return False
