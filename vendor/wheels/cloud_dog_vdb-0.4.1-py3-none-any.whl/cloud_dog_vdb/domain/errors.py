from __future__ import annotations


class VDBError(Exception):
    pass


class ConfigError(VDBError):
    pass


class BackendUnavailableError(VDBError):
    pass


class InvalidRequestError(VDBError):
    pass
