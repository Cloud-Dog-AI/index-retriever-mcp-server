from __future__ import annotations

from enum import Enum


class DistanceMetric(str, Enum):
    COSINE = "cosine"
    L2 = "l2"
    DOT = "dot"


class BackendType(str, Enum):
    CHROMA = "chroma"
    QDRANT = "qdrant"
    WEAVIATE = "weaviate"
    OPENSEARCH = "opensearch"
    PGVECTOR = "pgvector"
