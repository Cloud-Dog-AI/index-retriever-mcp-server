from __future__ import annotations

import time


def should_purge(created_at_epoch: float, retention_days: int) -> bool:
    return (time.time() - created_at_epoch) > max(0, retention_days) * 86400


def purge_candidates(records: list[dict], retention_days: int) -> list[dict]:
    out: list[dict] = []
    for record in records:
        created = float(record.get("metadata", {}).get("created_at_epoch", 0) or 0)
        if created and should_purge(created, retention_days):
            out.append(record)
    return out
