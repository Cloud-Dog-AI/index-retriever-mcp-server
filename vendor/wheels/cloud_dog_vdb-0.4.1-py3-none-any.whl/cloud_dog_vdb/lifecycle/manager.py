from __future__ import annotations


def mark_deleted(record: dict) -> dict:
    out = dict(record)
    out["lifecycle_state"] = "deleted"
    out["is_latest"] = False
    return out


def mark_superseded(record: dict) -> dict:
    out = dict(record)
    out["lifecycle_state"] = "superseded"
    out["is_latest"] = False
    return out
