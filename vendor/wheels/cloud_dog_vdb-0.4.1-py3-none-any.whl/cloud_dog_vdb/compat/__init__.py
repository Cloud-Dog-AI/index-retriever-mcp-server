# cloud_dog_vdb — Compatibility utilities
"""Compatibility helpers for legacy backend responses."""

from cloud_dog_vdb.compat.response_normaliser import ResponseNormaliser

__all__ = ["ResponseNormaliser"]
