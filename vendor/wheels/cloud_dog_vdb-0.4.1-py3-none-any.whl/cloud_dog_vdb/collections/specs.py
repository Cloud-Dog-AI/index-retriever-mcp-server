from __future__ import annotations

from cloud_dog_vdb.domain.models import CollectionSpec


def validate_spec(spec: CollectionSpec) -> None:
    if not spec.name.strip():
        raise ValueError("collection name is required")
    if spec.embedding_dim <= 0:
        raise ValueError("embedding_dim must be positive")


def spec_key(spec: CollectionSpec) -> str:
    namespace = spec.namespace.strip()
    return f"{namespace}:{spec.name}" if namespace else spec.name


__all__ = ["CollectionSpec", "validate_spec", "spec_key"]
