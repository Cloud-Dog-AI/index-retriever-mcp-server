from __future__ import annotations

from cloud_dog_vdb.domain.models import CollectionSpec


class CollectionManager:
    def __init__(self, vdb_client) -> None:
        self.vdb = vdb_client

    async def create(self, spec: CollectionSpec, provider_id: str | None = None) -> dict:
        return await self.vdb.create_collection(spec, provider_id)

    async def get(self, name: str, provider_id: str | None = None) -> dict | None:
        return await self.vdb.get_collection(name, provider_id)

    async def list(self, provider_id: str | None = None) -> list[dict]:
        return await self.vdb.list_collections(provider_id)

    async def update(self, name: str, patch: dict, provider_id: str | None = None) -> dict | None:
        return await self.vdb.update_collection(name, patch, provider_id)

    async def delete(self, name: str, provider_id: str | None = None) -> bool:
        return await self.vdb.delete_collection(name, provider_id)
