from __future__ import annotations

from typing import Any

from cloud_dog_vdb.runtime.client import VDBClient
from cloud_dog_vdb.runtime.factory import build_runtime_client


def get_vdb_client(config: dict[str, Any]) -> VDBClient:
    """Build runtime client from resolved config tree."""
    if not isinstance(config, dict):
        raise TypeError("config must be a dictionary")
    return build_runtime_client(config)
