from __future__ import annotations

from contextlib import contextmanager


def trace_enabled(*, enabled: bool = False) -> bool:
    """Feature flag hook.

    The caller passes this from resolved platform config; no local env reads.
    """
    return bool(enabled)


@contextmanager
def trace_span(name: str):
    """No-op span context with an OTel-compatible API shape."""
    _ = name
    yield
