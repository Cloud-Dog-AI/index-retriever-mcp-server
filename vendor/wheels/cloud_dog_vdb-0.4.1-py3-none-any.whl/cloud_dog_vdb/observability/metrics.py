from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class Metrics:
    counters: dict[str, int] = field(default_factory=dict)
    gauges: dict[str, float] = field(default_factory=dict)

    def inc(self, key: str, amount: int = 1) -> None:
        self.counters[key] = self.counters.get(key, 0) + amount

    def set_gauge(self, key: str, value: float) -> None:
        self.gauges[key] = float(value)

    def snapshot(self) -> dict[str, dict[str, float | int]]:
        return {"counters": dict(self.counters), "gauges": dict(self.gauges)}
