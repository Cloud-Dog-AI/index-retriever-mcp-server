from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def audit_event(
    action: str, target: str, *, actor: str = "system", outcome: str = "success", details: dict[str, Any] | None = None
) -> dict[str, Any]:
    return {
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        "action": action,
        "target": target,
        "actor": actor,
        "outcome": outcome,
        "details": details or {},
    }
