from __future__ import annotations


def pgvector_options(overrides: dict | None = None) -> dict:
    out = {
        "index_type": "ivfflat",
        "probes": 10,
        "lists": 100,
    }
    if overrides:
        out.update(overrides)
    out["probes"] = max(1, int(out.get("probes", 10)))
    return out
