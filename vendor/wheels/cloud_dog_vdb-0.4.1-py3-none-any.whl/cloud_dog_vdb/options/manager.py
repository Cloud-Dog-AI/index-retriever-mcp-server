from __future__ import annotations

from cloud_dog_vdb.options.chroma import chroma_options
from cloud_dog_vdb.options.opensearch import opensearch_options
from cloud_dog_vdb.options.pgvector import pgvector_options
from cloud_dog_vdb.options.qdrant import qdrant_options
from cloud_dog_vdb.options.weaviate import weaviate_options


def merge_options(store_type: str, overrides: dict | None = None) -> dict:
    mapping = {
        "chroma": chroma_options,
        "qdrant": qdrant_options,
        "weaviate": weaviate_options,
        "opensearch": opensearch_options,
        "pgvector": pgvector_options,
    }
    fn = mapping.get(store_type, lambda ov: ov or {})
    return fn(overrides)
