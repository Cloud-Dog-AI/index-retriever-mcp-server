from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CommonIndexingOptions:
    dimension: int = 1024
    distance_metric: str = "cosine"
    index_type: str = "hnsw"


@dataclass(frozen=True, slots=True)
class CommonSearchOptions:
    top_k: int = 10
    score_threshold: float = 0.0
    hybrid_enabled: bool = False
