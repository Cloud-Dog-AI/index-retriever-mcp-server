from __future__ import annotations


def opensearch_options(overrides: dict | None = None) -> dict:
    out = {
        "engine": "nmslib",
        "space_type": "cosinesimil",
        "ef_search": 128,
    }
    if overrides:
        out.update(overrides)
    out["ef_search"] = max(16, int(out.get("ef_search", 128)))
    return out
