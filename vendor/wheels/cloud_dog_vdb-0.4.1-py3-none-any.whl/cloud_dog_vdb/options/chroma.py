from __future__ import annotations


def chroma_options(overrides: dict | None = None) -> dict:
    out = {
        "hnsw_space": "cosine",
        "hnsw_m": 16,
        "hnsw_ef_construction": 100,
    }
    if overrides:
        out.update(overrides)
    out["hnsw_m"] = max(4, int(out.get("hnsw_m", 16)))
    return out
