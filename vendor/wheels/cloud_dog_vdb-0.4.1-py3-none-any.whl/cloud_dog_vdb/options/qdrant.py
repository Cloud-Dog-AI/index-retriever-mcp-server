from __future__ import annotations


def qdrant_options(overrides: dict | None = None) -> dict:
    out = {
        "quantization": "none",
        "hnsw_ef": 128,
        "exact": False,
    }
    if overrides:
        out.update(overrides)
    out["hnsw_ef"] = max(16, int(out.get("hnsw_ef", 128)))
    return out
