from __future__ import annotations


def weaviate_options(overrides: dict | None = None) -> dict:
    out = {
        "vectorizer": "none",
        "index_type": "hnsw",
        "ef": 64,
    }
    if overrides:
        out.update(overrides)
    out["ef"] = max(16, int(out.get("ef", 64)))
    return out
