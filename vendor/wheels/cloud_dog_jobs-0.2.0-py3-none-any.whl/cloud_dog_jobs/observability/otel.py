# cloud_dog_jobs — OpenTelemetry integration hooks
"""Optional OpenTelemetry span wrapper."""

from __future__ import annotations

from contextlib import contextmanager


@contextmanager
def span(name: str):
    """Create an OpenTelemetry span when available, otherwise no-op."""
    try:
        from opentelemetry import trace  # type: ignore

        tracer = trace.get_tracer("cloud_dog_jobs")
        with tracer.start_as_current_span(name):
            yield
    except Exception:
        yield
