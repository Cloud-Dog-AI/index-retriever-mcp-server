# cloud_dog_jobs — Metrics hooks
"""In-memory counter-style metrics hooks."""


class Metrics:
    """Simple in-memory metrics collector."""

    def __init__(self) -> None:
        self._counters: dict[str, int] = {}

    def inc(self, key: str, value: int = 1) -> None:
        self._counters[key] = self._counters.get(key, 0) + value

    def get(self, key: str) -> int:
        return self._counters.get(key, 0)
