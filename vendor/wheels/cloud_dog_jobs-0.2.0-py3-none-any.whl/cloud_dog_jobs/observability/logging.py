# cloud_dog_jobs — Logging helpers
"""Redaction helper for secret-like fields."""


def redact_secrets(data: dict) -> dict:
    redacted = {}
    for key, value in data.items():
        if any(token in key.lower() for token in ("password", "secret", "token", "key", "credential")):
            redacted[key] = "***REDACTED***"
        else:
            redacted[key] = value
    return redacted
