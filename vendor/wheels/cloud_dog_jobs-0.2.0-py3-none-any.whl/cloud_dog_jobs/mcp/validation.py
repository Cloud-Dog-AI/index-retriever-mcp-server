# cloud_dog_jobs — MCP payload validation
"""MCP-facing validation helpers.

These wrappers keep MCP module layout aligned with architecture while
reusing the canonical security validation implementation.
"""

from __future__ import annotations

from cloud_dog_jobs.security.validation import validate_callback_url, validate_payload_size

__all__ = ["validate_callback_url", "validate_payload_size"]
