# cloud_dog_jobs — MCP secret exclusion
"""MCP-facing secret exclusion helpers.

These wrappers keep MCP module layout aligned with architecture while
reusing the canonical security secret checks.
"""

from __future__ import annotations

from cloud_dog_jobs.security.secrets import assert_no_secrets, payload_contains_secret

__all__ = ["assert_no_secrets", "payload_contains_secret"]
