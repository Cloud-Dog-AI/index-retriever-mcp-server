# cloud_dog_jobs — SQL backend implementation
"""SQLAlchemy backend supporting SQLite, MySQL, and PostgreSQL."""

from __future__ import annotations

from cloud_dog_jobs.backends.base import QueueBackend
from cloud_dog_jobs.domain.enums import JobStatus
from cloud_dog_jobs.domain.models import Job
from cloud_dog_jobs.storage.sqlalchemy.repo import SQLAlchemyJobRepository


class SQLQueueBackend(QueueBackend):
    """SQL queue backend with atomic claim semantics."""

    def __init__(self, database_url: str) -> None:
        self._repo = SQLAlchemyJobRepository(database_url)

    def enqueue(self, job: Job) -> str:
        return self._repo.enqueue(job)

    def dequeue(self, limit: int, job_type: str | None = None) -> list[Job]:
        return self._repo.queued(limit=limit, job_type=job_type)

    def claim(self, job_id: str, host_id: str, worker_id: str) -> bool:
        return self._repo.set_claimed(job_id, host_id=host_id, worker_id=worker_id)

    def release(self, job_id: str) -> bool:
        return self.update_status(job_id, JobStatus.QUEUED.value)

    def heartbeat(self, job_id: str) -> bool:
        return self._repo.heartbeat(job_id)

    def get(self, job_id: str) -> Job | None:
        return self._repo.get(job_id)

    def update_status(self, job_id: str, status: str) -> bool:
        return self._repo.set_status(job_id, status)

    def get_queue_status(self) -> dict[str, int]:
        return self._repo.queue_status()

    def health_check(self) -> bool:
        return self._repo.health_check()

    def all_jobs(self) -> list[Job]:
        """Return all jobs for admin and maintenance use cases."""
        return self._repo.all_jobs()

    def close(self) -> None:
        """Dispose engine connections, used by integration tests and shutdown hooks."""
        self._repo.close()
