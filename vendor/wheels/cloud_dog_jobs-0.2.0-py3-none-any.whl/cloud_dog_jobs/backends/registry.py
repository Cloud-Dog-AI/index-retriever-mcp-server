# cloud_dog_jobs — Backend registry
"""Factory helpers for backend selection and graceful fallback."""

from cloud_dog_jobs.backends.memory_backend import MemoryQueueBackend
from cloud_dog_jobs.backends.redis_backend import RedisQueueBackend
from cloud_dog_jobs.backends.sql_backend import SQLQueueBackend


def select_backend(preferred: str, *, sql_url: str | None = None, redis_url: str | None = None):
    """Select backend by name with fallback to SQL/memory."""
    if preferred == "redis" and redis_url:
        backend = RedisQueueBackend(redis_url)
        if backend.health_check():
            return backend
        if sql_url:
            return SQLQueueBackend(sql_url)
        return MemoryQueueBackend()
    if preferred == "sql" and sql_url:
        return SQLQueueBackend(sql_url)
    return MemoryQueueBackend()
