# cloud_dog_jobs — Hybrid backend
"""Hybrid backend using Redis queue operations with SQL source-of-truth state."""

from __future__ import annotations

from cloud_dog_jobs.backends.base import QueueBackend
from cloud_dog_jobs.backends.redis_backend import RedisQueueBackend
from cloud_dog_jobs.backends.sql_backend import SQLQueueBackend
from cloud_dog_jobs.domain.models import Job


class HybridQueueBackend(QueueBackend):
    """Redis for dispatch operations, SQL for durable state."""

    def __init__(self, redis_backend: RedisQueueBackend, sql_backend: SQLQueueBackend) -> None:
        self._redis = redis_backend
        self._sql = sql_backend

    def enqueue(self, job: Job) -> str:
        self._sql.enqueue(job)
        return self._redis.enqueue(job)

    def dequeue(self, limit: int, job_type: str | None = None) -> list[Job]:
        return self._redis.dequeue(limit, job_type)

    def claim(self, job_id: str, host_id: str, worker_id: str) -> bool:
        if not self._redis.claim(job_id, host_id, worker_id):
            return False
        self._sql.claim(job_id, host_id, worker_id)
        return True

    def release(self, job_id: str) -> bool:
        self._sql.release(job_id)
        return self._redis.release(job_id)

    def heartbeat(self, job_id: str) -> bool:
        self._sql.heartbeat(job_id)
        return self._redis.heartbeat(job_id)

    def get(self, job_id: str) -> Job | None:
        return self._sql.get(job_id)

    def update_status(self, job_id: str, status: str) -> bool:
        self._redis.update_status(job_id, status)
        return self._sql.update_status(job_id, status)

    def get_queue_status(self) -> dict[str, int]:
        return self._sql.get_queue_status()

    def health_check(self) -> bool:
        return self._sql.health_check() and self._redis.health_check()

    def all_jobs(self) -> list[Job]:
        """Return all jobs from durable SQL source-of-truth."""
        return self._sql.all_jobs()
