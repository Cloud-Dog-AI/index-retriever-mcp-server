# cloud_dog_jobs — Retention utilities
"""Retention helpers for purging old records."""

from datetime import datetime, timezone


def should_purge(updated_at: datetime, max_age_seconds: int, now: datetime | None = None) -> bool:
    current = now or datetime.now(timezone.utc)
    return (current - updated_at).total_seconds() > max_age_seconds
