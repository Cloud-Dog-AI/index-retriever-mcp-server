# cloud_dog_jobs — TTL expiry utilities
"""TTL expiration checks and transitions."""

from datetime import datetime, timezone


def is_ttl_expired(created_at: datetime, ttl_seconds: int, now: datetime | None = None) -> bool:
    """Return true when TTL has elapsed."""
    current = now or datetime.now(timezone.utc)
    return (current - created_at).total_seconds() > ttl_seconds
