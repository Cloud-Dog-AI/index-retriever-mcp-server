# cloud_dog_jobs — Domain enums for job and queue state
"""Enum definitions for job status."""

from __future__ import annotations

from enum import Enum


class JobStatus(str, Enum):
    """Canonical job lifecycle states for the default implementation."""

    QUEUED = "queued"
    SCHEDULED = "scheduled"
    RUNNING = "running"
    RETRY_WAIT = "retry_wait"
    PAUSED = "paused"
    TIMEOUT = "timeout"
    TTL_EXPIRED = "ttl_expired"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
