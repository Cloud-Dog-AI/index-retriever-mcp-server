# cloud_dog_jobs — Error taxonomy
"""Domain-specific error classes."""


class JobError(Exception):
    """Base error for job subsystem."""


class InvalidTransitionError(JobError):
    """Raised when state transition is not allowed."""


class PayloadValidationError(JobError):
    """Raised when payload fails validation."""
