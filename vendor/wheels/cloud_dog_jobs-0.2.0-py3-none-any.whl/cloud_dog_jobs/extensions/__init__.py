# cloud_dog_jobs — Extension package

from cloud_dog_jobs.extensions.fallback_policies import (
    FallbackAction,
    FallbackDecision,
    FallbackPolicy,
    FallbackPolicyManager,
)
from cloud_dog_jobs.extensions.state_extensions import StateExtension, StateExtensionRegistry, register_state_extension

__all__ = [
    "FallbackAction",
    "FallbackDecision",
    "FallbackPolicy",
    "FallbackPolicyManager",
    "StateExtension",
    "StateExtensionRegistry",
    "register_state_extension",
]
