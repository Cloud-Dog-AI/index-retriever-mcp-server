# cloud_dog_jobs — Idempotency manager
"""In-memory idempotency key deduplication."""

from __future__ import annotations

import time


class IdempotencyManager:
    """Track idempotency keys for a bounded TTL window."""

    def __init__(self, ttl_seconds: int = 86_400) -> None:
        self._ttl_seconds = ttl_seconds
        self._entries: dict[str, tuple[str, float]] = {}

    def register_or_get(self, key: str, job_id: str) -> str:
        """Return existing job_id if key exists and valid, otherwise store new entry."""
        now = time.time()
        existing = self._entries.get(key)
        if existing and existing[1] > now:
            return existing[0]
        self._entries[key] = (job_id, now + self._ttl_seconds)
        return job_id
