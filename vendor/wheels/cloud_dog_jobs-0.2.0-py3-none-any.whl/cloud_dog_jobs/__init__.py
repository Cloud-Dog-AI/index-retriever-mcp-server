# cloud_dog_jobs — PS-75 Job & Queue Management for Cloud-Dog services
"""Public API for cloud_dog_jobs."""

from cloud_dog_jobs.admin.service import AdminService
from cloud_dog_jobs.async_jobs.mcp_adapter import MCPAsyncJobAdapter
from cloud_dog_jobs.backends.hybrid_backend import HybridQueueBackend
from cloud_dog_jobs.backends.memory_backend import MemoryQueueBackend
from cloud_dog_jobs.backends.redis_backend import RedisQueueBackend
from cloud_dog_jobs.backends.sql_backend import SQLQueueBackend
from cloud_dog_jobs.domain.enums import JobStatus
from cloud_dog_jobs.domain.models import Job, JobRequest
from cloud_dog_jobs.domain.state_machine import JobStateMachine
from cloud_dog_jobs.extensions.fallback_policies import FallbackAction, FallbackPolicy, FallbackPolicyManager
from cloud_dog_jobs.extensions.state_extensions import register_state_extension
from cloud_dog_jobs.mcp.job_tools import create_job_tools
from cloud_dog_jobs.queue import JobQueue
from cloud_dog_jobs.worker.worker import Worker

__all__ = [
    "AdminService",
    "HybridQueueBackend",
    "Job",
    "JobQueue",
    "JobRequest",
    "JobStateMachine",
    "JobStatus",
    "MCPAsyncJobAdapter",
    "MemoryQueueBackend",
    "FallbackAction",
    "FallbackPolicy",
    "FallbackPolicyManager",
    "create_job_tools",
    "register_state_extension",
    "RedisQueueBackend",
    "SQLQueueBackend",
    "Worker",
]

__version__ = "0.2.0"
