# cloud_dog_jobs — Confirmation polling
"""External confirmation poll tracker."""

from dataclasses import dataclass


@dataclass(slots=True)
class PollPolicy:
    interval_seconds: int = 30
    max_age_seconds: int = 3600


def should_continue_polling(age_seconds: int, policy: PollPolicy) -> bool:
    """Return whether polling should continue for given age."""
    return age_seconds <= policy.max_age_seconds
