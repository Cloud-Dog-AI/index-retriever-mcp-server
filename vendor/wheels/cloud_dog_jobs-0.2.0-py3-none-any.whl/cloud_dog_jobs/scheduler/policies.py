# cloud_dog_jobs — Retry and scheduling policies
"""Retry, backoff, and fairness helpers."""

from __future__ import annotations

import random


def exponential_backoff_seconds(attempt: int, base: float = 2.0, maximum: float = 300.0, jitter: bool = True) -> float:
    """Calculate exponential backoff with optional jitter."""
    backoff = min(base * (2 ** max(attempt, 0)), maximum)
    if jitter:
        backoff += random.uniform(0.0, backoff * 0.1)
    return backoff


def fixed_backoff_seconds(value: float) -> float:
    """Return fixed backoff interval."""
    return max(0.0, value)
