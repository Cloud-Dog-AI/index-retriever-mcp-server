# cloud_dog_jobs — Heartbeat manager
"""Heartbeat update helper."""

from cloud_dog_jobs.backends.base import QueueBackend


class HeartbeatManager:
    """Backend heartbeat wrapper."""

    def __init__(self, backend: QueueBackend) -> None:
        self._backend = backend

    def touch(self, job_id: str) -> bool:
        return self._backend.heartbeat(job_id)
