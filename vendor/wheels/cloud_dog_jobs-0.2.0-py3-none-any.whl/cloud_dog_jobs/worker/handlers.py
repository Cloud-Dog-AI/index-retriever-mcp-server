# cloud_dog_jobs — Handler registry
"""Job type to handler registration and retrieval."""

from __future__ import annotations

from collections.abc import Callable

from cloud_dog_jobs.worker.context import JobContext

JobHandler = Callable[[JobContext], dict]


class HandlerRegistry:
    """Registry of handlers keyed by job type."""

    def __init__(self) -> None:
        self._handlers: dict[str, JobHandler] = {}

    def register(self, job_type: str, handler: JobHandler) -> None:
        """Register a handler for a job type."""
        self._handlers[job_type] = handler

    def get(self, job_type: str) -> JobHandler:
        """Get handler for job type; raise if not registered."""
        if job_type not in self._handlers:
            raise KeyError(f"Unknown job_type: {job_type}")
        return self._handlers[job_type]
