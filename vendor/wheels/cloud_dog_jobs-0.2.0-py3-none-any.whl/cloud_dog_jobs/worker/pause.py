# cloud_dog_jobs — Pause controls
"""Simple pause/resume controls for cooperative handlers."""

from threading import Event


class PauseController:
    """Pause and resume control primitive."""

    def __init__(self) -> None:
        self._paused = Event()

    def pause_task(self) -> None:
        self._paused.set()

    def resume_task(self) -> None:
        self._paused.clear()

    def is_paused(self) -> bool:
        return self._paused.is_set()
