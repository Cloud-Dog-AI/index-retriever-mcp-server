# cloud_dog_jobs — Mock backends for tests
"""In-memory mock backend implementations for focused unit tests."""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone

from cloud_dog_jobs.backends.base import QueueBackend
from cloud_dog_jobs.domain.enums import JobStatus
from cloud_dog_jobs.domain.models import Job


class MockQueueBackend(QueueBackend):
    def __init__(self) -> None:
        self._jobs: dict[str, Job] = {}

    def enqueue(self, job: Job) -> str:
        self._jobs[job.job_id] = job
        return job.job_id

    def dequeue(self, limit: int, job_type: str | None = None) -> list[Job]:
        jobs = [j for j in self._jobs.values() if j.status == JobStatus.QUEUED]
        if job_type:
            jobs = [j for j in jobs if j.job_type == job_type]
        jobs.sort(key=lambda j: (-j.priority, j.created_at))
        return jobs[:limit]

    def claim(self, job_id: str, host_id: str, worker_id: str) -> bool:
        job = self._jobs.get(job_id)
        if job is None or job.status != JobStatus.QUEUED:
            return False
        job.status = JobStatus.RUNNING
        job.claimed_by = f"{host_id}:{worker_id}"
        job.updated_at = datetime.now(tz=timezone.utc)
        return True

    def release(self, job_id: str) -> bool:
        return self.update_status(job_id, JobStatus.QUEUED.value)

    def heartbeat(self, job_id: str) -> bool:
        job = self._jobs.get(job_id)
        if job is None:
            return False
        job.updated_at = datetime.now(tz=timezone.utc)
        return True

    def get(self, job_id: str) -> Job | None:
        return self._jobs.get(job_id)

    def update_status(self, job_id: str, status: str) -> bool:
        job = self._jobs.get(job_id)
        if job is None:
            return False
        job.status = JobStatus(status)
        job.updated_at = datetime.now(tz=timezone.utc)
        if job.status != JobStatus.RUNNING:
            job.claimed_by = None
        return True

    def get_queue_status(self) -> dict[str, int]:
        return dict(Counter(j.status.value for j in self._jobs.values()))

    def health_check(self) -> bool:
        return True

    def all_jobs(self) -> list[Job]:
        return list(self._jobs.values())
