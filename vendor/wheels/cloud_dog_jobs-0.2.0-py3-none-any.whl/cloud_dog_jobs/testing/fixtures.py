# cloud_dog_jobs — Testing fixtures
"""Shared test fixture builders for jobs and requests."""

from __future__ import annotations

from datetime import datetime, timezone

from cloud_dog_jobs.domain.models import Job, JobRequest


def sample_job_request(*, job_type: str = "test.echo", queue_name: str = "default", priority: int = 0) -> JobRequest:
    return JobRequest(job_type=job_type, queue_name=queue_name, payload={"value": "ok"}, priority=priority)


def sample_job(*, job_type: str = "test.echo", queue_name: str = "default", priority: int = 0) -> Job:
    req = sample_job_request(job_type=job_type, queue_name=queue_name, priority=priority)
    return Job.from_request(req)


def utc_now() -> datetime:
    return datetime.now(tz=timezone.utc)
