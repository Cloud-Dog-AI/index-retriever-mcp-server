# cloud_dog_jobs — FastAPI router
"""Minimal FastAPI router for queue status and job lookup."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from cloud_dog_jobs.admin.service import AdminService


def build_router(admin: AdminService) -> APIRouter:
    """Build the jobs admin router with read-only endpoints."""
    router = APIRouter(prefix="/jobs", tags=["jobs"])

    @router.get("/queue/status")
    def queue_status() -> dict[str, int]:
        return admin.queue_status()

    @router.get("")
    def list_jobs(limit: int = 100) -> list[dict]:
        jobs = admin.list_jobs(limit=limit)
        return [
            {
                "job_id": job.job_id,
                "job_type": job.job_type,
                "status": job.status.value,
                "priority": job.priority,
            }
            for job in jobs
        ]

    @router.get("/{job_id}")
    def get_job(job_id: str) -> dict:
        job = admin.get_job(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        return {
            "job_id": job.job_id,
            "job_type": job.job_type,
            "status": job.status.value,
            "priority": job.priority,
        }

    @router.delete("/{job_id}")
    def delete_job(job_id: str) -> dict[str, bool]:
        return {"deleted": admin.delete_job(job_id)}

    @router.post("/{job_id}/resubmit")
    def resubmit_job(job_id: str) -> dict[str, str]:
        new_job_id = admin.resubmit_job(job_id)
        if new_job_id is None:
            raise HTTPException(status_code=404, detail="Job not found")
        return {"job_id": new_job_id}

    @router.post("/{job_id}/stop")
    def stop_job(job_id: str) -> dict[str, bool]:
        return {"cancelled": admin.cancel_job(job_id)}

    return router
