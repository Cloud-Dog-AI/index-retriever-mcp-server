# cloud_dog_jobs — Secret exclusion checks
"""Helpers to detect and reject likely secrets in payloads."""

from __future__ import annotations

from typing import Any

_SECRET_TOKENS = ("password", "secret", "token", "api_key", "private_key", "credential")


def payload_contains_secret(payload: Any) -> bool:
    if isinstance(payload, dict):
        for key, value in payload.items():
            key_l = str(key).lower()
            if any(token in key_l for token in _SECRET_TOKENS):
                return True
            if payload_contains_secret(value):
                return True
        return False
    if isinstance(payload, list):
        return any(payload_contains_secret(item) for item in payload)
    if isinstance(payload, str):
        value_l = payload.lower()
        return any(token in value_l for token in ("bearer ", "sk-", "-----begin", "xox", "ghp_"))
    return False


def assert_no_secrets(payload: Any) -> None:
    if payload_contains_secret(payload):
        raise ValueError("Payload appears to contain secret material")
