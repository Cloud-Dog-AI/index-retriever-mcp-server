# cloud_dog_jobs — Security validation utilities
"""Payload and callback URL validation helpers."""

from __future__ import annotations

from urllib.parse import urlparse


def validate_payload_size(payload: dict, max_bytes: int = 16_384) -> None:
    """Raise when payload exceeds maximum byte size."""
    size = len(str(payload).encode("utf-8"))
    if size > max_bytes:
        raise ValueError(f"Payload size {size} exceeds max {max_bytes}")


def validate_callback_url(url: str) -> None:
    """Allow only HTTP/HTTPS callback URLs."""
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("Only http/https callback URLs are allowed")
