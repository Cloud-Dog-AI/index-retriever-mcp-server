# cloud_dog_jobs — RBAC hooks
"""Minimal RBAC authorisation hooks for admin operations."""

from __future__ import annotations


def check_permission(granted_permissions: set[str], required_permission: str) -> bool:
    """Return True only when required permission is explicitly granted."""
    return required_permission in granted_permissions


def require_permission(granted_permissions: set[str], required_permission: str) -> None:
    """Raise PermissionError when permission is missing."""
    if not check_permission(granted_permissions, required_permission):
        raise PermissionError(f"Missing required permission: {required_permission}")
