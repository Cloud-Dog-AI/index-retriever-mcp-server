# cloud_dog_llm — Middleware base abstractions
"""Composable middleware interfaces for LLM runtime request pipelines."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol

from cloud_dog_llm.domain.models import LLMRequest, LLMResponse, SessionContext


class LLMMiddleware(Protocol):
    enabled: bool

    async def pre_request(self, request: LLMRequest, session: SessionContext) -> LLMRequest: ...

    async def post_response(
        self,
        request: LLMRequest,
        response: LLMResponse,
        session: SessionContext,
    ) -> LLMResponse: ...

    async def on_error(
        self,
        request: LLMRequest,
        error: Exception,
        session: SessionContext,
    ) -> LLMResponse | Exception | None: ...


class ShortCircuitResponse(Exception):
    """Raised by middleware to bypass provider execution with a ready response."""

    def __init__(self, response: LLMResponse) -> None:
        super().__init__("LLM request short-circuited by middleware")
        self.response = response


class MiddlewareChain:
    def __init__(self, middlewares: list[LLMMiddleware] | None = None) -> None:
        self._middlewares = [m for m in (middlewares or []) if getattr(m, "enabled", True)]

    async def run(
        self,
        request: LLMRequest,
        session: SessionContext,
        invoke: Callable[[LLMRequest], Awaitable[LLMResponse]],
    ) -> LLMResponse:
        current_request = request
        executed: list[LLMMiddleware] = []

        try:
            for middleware in self._middlewares:
                current_request = await middleware.pre_request(current_request, session)
                executed.append(middleware)
            response = await invoke(current_request)
        except ShortCircuitResponse as short_circuit:
            response = short_circuit.response
        except Exception as exc:
            handled: LLMResponse | Exception | None = None
            for middleware in reversed(executed):
                handled = await middleware.on_error(current_request, exc, session)
                if isinstance(handled, LLMResponse):
                    response = handled
                    break
                if isinstance(handled, Exception):
                    exc = handled
            else:
                raise exc

        for middleware in reversed(executed):
            response = await middleware.post_response(current_request, response, session)
        return response
