# cloud_dog_llm — Runtime parameter handling
"""Provider-agnostic parameter normalisation for request passthrough."""

from __future__ import annotations

from typing import Any


def split_provider_params(params: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """Split general params from provider-scoped keys.

    Keys prefixed with ``x_provider.`` are kept in the provider-specific dict
    with the prefix removed.
    """
    common: dict[str, Any] = {}
    provider: dict[str, Any] = {}
    for key, value in params.items():
        if key.startswith("x_provider."):
            provider[key[len("x_provider.") :]] = value
        else:
            common[key] = value
    return common, provider
