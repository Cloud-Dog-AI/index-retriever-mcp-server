# cloud_dog_llm — Cancellation helpers
"""Small cancellation primitives for tests and integrations."""

from __future__ import annotations

import asyncio


class CancellationToken:
    def __init__(self) -> None:
        self._event = asyncio.Event()

    def cancel(self) -> None:
        self._event.set()

    async def wait_cancelled(self) -> None:
        await self._event.wait()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()
