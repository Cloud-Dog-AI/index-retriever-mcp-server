# cloud_dog_llm — Timeout compatibility module
"""Compatibility wrapper for timeout helpers."""

from __future__ import annotations

from collections.abc import Awaitable
from typing import TypeVar

from cloud_dog_llm.runtime.timeouts import with_timeout

T = TypeVar("T")


async def apply_timeout(coro: Awaitable[T], timeout_seconds: float) -> T:
    return await with_timeout(coro, timeout_seconds)
