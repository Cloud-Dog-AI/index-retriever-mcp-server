# cloud_dog_llm — Timeout helpers
"""Shared timeout wrapper."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable
from typing import TypeVar

T = TypeVar("T")


async def with_timeout(coro: Awaitable[T], timeout_seconds: float) -> T:
    return await asyncio.wait_for(coro, timeout=timeout_seconds)
