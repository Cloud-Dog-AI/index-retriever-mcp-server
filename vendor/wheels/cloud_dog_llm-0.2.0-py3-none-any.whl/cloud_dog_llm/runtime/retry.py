# cloud_dog_llm — Retry compatibility module
"""Compatibility wrapper with explicit retry policy support."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TypeVar

from cloud_dog_llm.runtime.retries import is_retryable_status, with_retries

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Policy configuration used by callers that import runtime.retry."""

    retries: int = 2
    base_delay_seconds: float = 0.01


async def run_with_retry(fn, policy: RetryPolicy | None = None) -> T:
    active = policy or RetryPolicy()
    return await with_retries(
        fn,
        retries=active.retries,
        base_delay_seconds=active.base_delay_seconds,
    )


__all__ = ["RetryPolicy", "is_retryable_status", "run_with_retry"]
