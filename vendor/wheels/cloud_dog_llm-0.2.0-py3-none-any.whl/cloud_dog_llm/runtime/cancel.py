# cloud_dog_llm — Cancellation compatibility module
"""Compatibility wrapper for cancellation primitives."""

from __future__ import annotations

from cloud_dog_llm.runtime.cancellation import CancellationToken


def is_cancelled(token: CancellationToken) -> bool:
    return token.cancelled


__all__ = ["CancellationToken", "is_cancelled"]
