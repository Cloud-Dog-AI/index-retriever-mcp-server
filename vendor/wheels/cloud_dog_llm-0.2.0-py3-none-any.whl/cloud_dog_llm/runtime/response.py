# cloud_dog_llm — Runtime response helpers
"""Helpers for constructing unified LLMResponse objects."""

from __future__ import annotations

import uuid
from typing import Any

from cloud_dog_llm.domain.enums import FinishReason
from cloud_dog_llm.domain.models import LLMResponse, Usage


def build_response(
    *,
    provider_id: str,
    model_id: str,
    content: str,
    request_id: str | None = None,
    usage: Usage | None = None,
    finish_reason: FinishReason = FinishReason.STOP,
    raw_provider_response: dict[str, Any] | None = None,
) -> LLMResponse:
    return LLMResponse(
        request_id=request_id or uuid.uuid4().hex,
        provider_id=provider_id,
        model_id=model_id,
        content=content,
        usage=usage or Usage(),
        finish_reason=finish_reason,
        raw_provider_response=raw_provider_response,
    )
