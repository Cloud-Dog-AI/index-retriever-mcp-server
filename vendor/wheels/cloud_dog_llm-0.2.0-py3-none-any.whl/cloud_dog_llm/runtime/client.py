# cloud_dog_llm — Runtime LLM client
"""Main runtime client coordinating provider adapters and embeddings."""

from __future__ import annotations

from collections.abc import AsyncIterator

from cloud_dog_llm.domain.models import LLMEvent, LLMRequest, LLMResponse, Message, SessionContext
from cloud_dog_llm.embeddings.manager import EmbeddingManager
from cloud_dog_llm.middleware.base import LLMMiddleware, MiddlewareChain
from cloud_dog_llm.providers.registry import ProviderRegistry


class LLMClient:
    def __init__(
        self,
        provider_registry: ProviderRegistry,
        default_provider_id: str,
        *,
        middlewares: list[LLMMiddleware] | None = None,
    ) -> None:
        self._providers = provider_registry
        self._default_provider_id = default_provider_id
        self._middleware_chain = MiddlewareChain(middlewares)

    def _provider_for(self, request: LLMRequest):
        provider_id = request.provider_id or self._default_provider_id
        return self._providers.get(provider_id)

    async def chat(self, request: LLMRequest, session: SessionContext) -> LLMResponse:
        async def _invoke(req: LLMRequest) -> LLMResponse:
            return await self._provider_for(req).invoke(req)

        return await self._middleware_chain.run(request, session, _invoke)

    async def complete(
        self,
        prompt: str,
        *,
        session: SessionContext,
        provider_id: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> LLMResponse:
        request = LLMRequest(
            provider_id=provider_id,
            model=model,
            max_tokens=max_tokens,
            messages=[Message(role="user", content=prompt)],
        )
        return await self.chat(request, session)

    async def chat_stream(self, request: LLMRequest, session: SessionContext) -> AsyncIterator[LLMEvent]:
        _ = session
        async for event in self._provider_for(request).invoke_stream(request):
            yield event

    async def embed(
        self, texts: list[str], *, provider_id: str | None = None, model: str | None = None
    ) -> list[list[float]]:
        pid = provider_id or self._default_provider_id
        manager = EmbeddingManager(self._providers.get(pid), model=model)
        return await manager.generate_embeddings(texts)

    async def health(self) -> bool:
        for pid in self._providers.list_ids():
            if not await self._providers.get(pid).health():
                return False
        return True
