# cloud_dog_llm — Runtime session helpers
"""Session context helpers."""

from __future__ import annotations

from cloud_dog_llm.domain.models import SessionContext


def ensure_session(ctx: SessionContext | None) -> SessionContext:
    if ctx is None:
        return SessionContext(session_id="default", correlation_id="default")
    return ctx
