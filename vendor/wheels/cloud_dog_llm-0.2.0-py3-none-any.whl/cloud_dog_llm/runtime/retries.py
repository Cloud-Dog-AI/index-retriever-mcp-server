# cloud_dog_llm — Retry helpers
"""Bounded retries with exponential backoff and retryable code helpers."""

from __future__ import annotations

import asyncio
import random
from collections.abc import Awaitable, Callable
from typing import TypeVar

T = TypeVar("T")

RETRYABLE_STATUS_CODES = {502, 503, 504}


def is_retryable_status(status_code: int) -> bool:
    return status_code in RETRYABLE_STATUS_CODES


async def with_retries(
    fn: Callable[[], Awaitable[T]],
    *,
    retries: int = 2,
    base_delay_seconds: float = 0.01,
) -> T:
    attempt = 0
    while True:
        try:
            return await fn()
        except Exception:
            if attempt >= retries:
                raise
            delay = base_delay_seconds * (2**attempt) + random.uniform(0.0, base_delay_seconds)
            await asyncio.sleep(delay)
            attempt += 1
