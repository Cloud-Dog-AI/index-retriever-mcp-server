# cloud_dog_llm — Lightweight VCR recorder
"""Minimal cassette recorder/replayer for HTTP tests."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

import httpx


@dataclass(frozen=True, slots=True)
class RecordedExchange:
    method: str
    url: str
    request_body: str
    status_code: int
    response_body: str
    headers: dict[str, str]


class SimpleVCR:
    def __init__(self, cassette_path: str) -> None:
        self.path = Path(cassette_path)
        self._records: list[RecordedExchange] = []
        if self.path.is_file():
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            self._records = [RecordedExchange(**item) for item in raw]

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        serialised = [asdict(r) for r in self._records]
        self.path.write_text(json.dumps(serialised, indent=2, sort_keys=True), encoding="utf-8")

    def replay(self, request: httpx.Request) -> httpx.Response | None:
        req_body = (request.content or b"").decode("utf-8", errors="replace")
        for item in self._records:
            if item.method == request.method and item.url == str(request.url) and item.request_body == req_body:
                return httpx.Response(
                    status_code=item.status_code,
                    headers=item.headers,
                    content=item.response_body.encode("utf-8"),
                    request=request,
                )
        return None

    def record(self, request: httpx.Request, response: httpx.Response) -> None:
        req_body = (request.content or b"").decode("utf-8", errors="replace")
        resp_body = response.text
        self._records.append(
            RecordedExchange(
                method=request.method,
                url=str(request.url),
                request_body=req_body,
                status_code=response.status_code,
                response_body=resp_body,
                headers={k: v for k, v in response.headers.items()},
            )
        )
