from __future__ import annotations

import uuid

from cloud_dog_llm.domain.models import Message
from cloud_dog_llm.runtime.session import ensure_session


def sample_messages() -> list[Message]:
    return [Message(role="user", content="hello")]


def sample_session():
    return ensure_session(None)


def random_correlation_id() -> str:
    return uuid.uuid4().hex
