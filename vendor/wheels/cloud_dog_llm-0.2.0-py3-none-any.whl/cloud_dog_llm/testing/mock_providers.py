from __future__ import annotations

from collections.abc import AsyncIterator

from cloud_dog_llm.domain.enums import EventType
from cloud_dog_llm.domain.models import LLMEvent, LLMRequest, LLMResponse
from cloud_dog_llm.providers.base import ProviderAdapter
from cloud_dog_llm.registry.capabilities import CapabilityDescriptor


class MockProvider(ProviderAdapter):
    async def invoke(self, request: LLMRequest) -> LLMResponse:
        return LLMResponse(request_id="r1", provider_id="mock", model_id=request.model or "mock", content="ok")

    async def invoke_stream(self, request: LLMRequest) -> AsyncIterator[LLMEvent]:
        yield LLMEvent(EventType.RESPONSE_STARTED, "r1", "mock", request.model or "mock")
        yield LLMEvent(EventType.DELTA_TEXT, "r1", "mock", request.model or "mock", text="ok")
        yield LLMEvent(EventType.RESPONSE_COMPLETED, "r1", "mock", request.model or "mock")

    async def health(self) -> bool:
        return True

    def capabilities(self) -> CapabilityDescriptor:
        return CapabilityDescriptor(provider_id="mock", model_id="mock")
