# cloud_dog_llm — Conformance checks
"""Basic PS-50 conformance checks for adapters and client wiring."""

from __future__ import annotations

from cloud_dog_llm.providers.base import ProviderAdapter


def adapter_has_required_methods(adapter: ProviderAdapter) -> bool:
    required = ["invoke", "invoke_stream", "health", "capabilities"]
    for method in required:
        if not hasattr(adapter, method):
            return False
    return True
