from __future__ import annotations

from cloud_dog_llm.mcp.client import MCPClient


def from_fastmcp_url(base_url: str) -> MCPClient:
    return MCPClient(base_url)


def from_fastmcp_config(config: dict) -> MCPClient:
    base_url = str(config.get("base_url", "")).strip()
    if not base_url:
        raise ValueError("FastMCP config requires non-empty base_url")
    transport = str(config.get("transport", "http_jsonrpc"))
    return MCPClient(base_url, transport=transport)
