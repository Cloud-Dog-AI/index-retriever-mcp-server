# cloud_dog_llm — MCP transport selector
"""Factory for MCP transport instances by name."""

from __future__ import annotations

import httpx

from cloud_dog_llm.mcp.transports.http_jsonrpc import HTTPJSONRPCTransport
from cloud_dog_llm.mcp.transports.legacy_sse import LegacySSETransport
from cloud_dog_llm.mcp.transports.stdio import StdioTransport
from cloud_dog_llm.mcp.transports.streamable_http import StreamableHTTPTransport


def select_transport(name: str, base_url: str, client: httpx.AsyncClient, headers: dict[str, str]):
    if name == "streamable_http":
        return StreamableHTTPTransport(base_url, client, headers)
    if name == "legacy_sse":
        return LegacySSETransport(base_url, client, headers)
    if name == "stdio":
        return StdioTransport()
    return HTTPJSONRPCTransport(base_url, client, headers)
