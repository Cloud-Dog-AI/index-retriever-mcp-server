from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class MCPSession:
    session_id: str = ""

    def headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
        return headers
