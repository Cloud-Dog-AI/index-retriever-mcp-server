from __future__ import annotations

from typing import Any


class StdioTransport:
    def __init__(self) -> None:
        self.last_payload: dict[str, Any] | None = None

    async def send(self, payload: dict[str, Any]) -> dict[str, Any]:
        self.last_payload = payload
        return {"jsonrpc": "2.0", "id": payload.get("id", "0"), "result": {"echo": payload}}
