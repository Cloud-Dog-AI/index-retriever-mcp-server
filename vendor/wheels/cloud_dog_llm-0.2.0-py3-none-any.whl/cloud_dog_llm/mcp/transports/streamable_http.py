from __future__ import annotations

from typing import Any

import httpx


class StreamableHTTPTransport:
    def __init__(self, base_url: str, client: httpx.AsyncClient, headers: dict[str, str]) -> None:
        self.base_url = base_url.rstrip("/")
        self._client = client
        self._headers = headers

    async def send(self, payload: dict[str, Any]) -> dict[str, Any]:
        resp = await self._client.post(f"{self.base_url}/messages", headers=self._headers, json=payload)
        resp.raise_for_status()
        return resp.json()
