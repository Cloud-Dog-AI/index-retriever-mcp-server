# cloud_dog_llm — Settings model
"""High-level runtime settings resolved from config dictionaries."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class LLMSettings:
    default_provider: str = "ollama"
    connect_timeout_seconds: float = 30.0
    read_timeout_seconds: float = 300.0
    overall_timeout_seconds: float = 480.0


def settings_from_dict(raw: dict[str, Any]) -> LLMSettings:
    llm = raw.get("llm", {}) if isinstance(raw, dict) else {}
    return LLMSettings(
        default_provider=str(llm.get("default_provider", "ollama")),
        connect_timeout_seconds=float(llm.get("connect_timeout_seconds", 30.0) or 30.0),
        read_timeout_seconds=float(llm.get("read_timeout_seconds", 300.0) or 300.0),
        overall_timeout_seconds=float(llm.get("overall_timeout_seconds", 480.0) or 480.0),
    )
