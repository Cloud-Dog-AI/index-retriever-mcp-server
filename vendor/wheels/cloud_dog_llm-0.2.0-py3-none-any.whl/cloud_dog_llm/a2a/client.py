# cloud_dog_llm — A2A client
"""Simple A2A request/response and envelope normalisation."""

from __future__ import annotations

from typing import Any

import httpx

from cloud_dog_llm.a2a.envelope import normalize_envelope


class A2AClient:
    def __init__(self, base_url: str, client: httpx.AsyncClient | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self._client = client or httpx.AsyncClient(timeout=30.0)

    async def request(self, topic: str, payload: dict[str, Any], correlation_id: str) -> dict[str, Any]:
        response = await self._client.post(
            f"{self.base_url}/a2a/request",
            json={"topic": topic, "payload": payload},
            headers={"X-Correlation-Id": correlation_id},
        )
        data = response.json()
        return normalize_envelope(response.status_code, data, response.headers.get("X-Correlation-Id", correlation_id))
