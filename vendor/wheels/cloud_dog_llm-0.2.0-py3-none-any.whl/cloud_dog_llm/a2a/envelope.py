from __future__ import annotations

from typing import Any


def normalize_envelope(status_code: int, payload: dict[str, Any], correlation_id: str) -> dict[str, Any]:
    return {
        "ok": status_code < 400 and not payload.get("error"),
        "correlation_id": correlation_id,
        "data": payload.get("data"),
        "error": payload.get("error"),
    }
