# cloud_dog_llm — Domain formatter compatibility adapter
"""Wrap domain formatter callables as PromptTemplate-compatible objects."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from cloud_dog_llm.prompts.registry import PromptTemplate
from cloud_dog_llm.prompts.render import render_template


@dataclass(frozen=True, slots=True)
class _CompatRef:
    key: str


class FormatterCompatibilityAdapter:
    """Bridges function-based formatters with PromptTemplate flows."""

    def __init__(self) -> None:
        self._formatters: dict[str, Callable[[dict[str, Any]], str]] = {}

    def wrap(
        self,
        *,
        name: str,
        version: str,
        formatter: Callable[[dict[str, Any]], str],
    ) -> PromptTemplate:
        key = f"{name}@{version}"
        self._formatters[key] = formatter
        return PromptTemplate(name=name, version=version, template=f"{{{{compat:{key}}}}}")

    def render(self, template: PromptTemplate, variables: dict[str, Any]) -> str:
        marker = "{{compat:"
        if template.template.startswith(marker) and template.template.endswith("}}"):
            key = template.template[len(marker) : -2]
            formatter = self._formatters.get(key)
            if formatter is None:
                raise KeyError(f"Formatter not registered: {key}")
            return formatter(variables)
        return render_template(template.template, variables).text

    def render_chain(self, templates: list[PromptTemplate], variables: dict[str, Any]) -> list[str]:
        return [self.render(template, variables) for template in templates]
