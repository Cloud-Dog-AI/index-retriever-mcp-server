# cloud_dog_llm — Compatibility adapters

from cloud_dog_llm.compat.formatter_compat import FormatterCompatibilityAdapter
from cloud_dog_llm.compat.response_adapter import ResponseAdapter, ResponseNormalisationError

__all__ = ["FormatterCompatibilityAdapter", "ResponseAdapter", "ResponseNormalisationError"]
