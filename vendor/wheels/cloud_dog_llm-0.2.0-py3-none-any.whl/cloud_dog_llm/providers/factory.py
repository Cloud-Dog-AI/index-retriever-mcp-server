# cloud_dog_llm — Provider factory
"""Factory helpers for concrete provider adapter creation."""

from __future__ import annotations

from cloud_dog_llm.config.models import ProviderConfig
from cloud_dog_llm.providers.anthropic import AnthropicAdapter
from cloud_dog_llm.providers.base import ProviderAdapter
from cloud_dog_llm.providers.ollama import OllamaAdapter
from cloud_dog_llm.providers.openai import OpenAIAdapter
from cloud_dog_llm.providers.openai_compat import OpenAICompatAdapter
from cloud_dog_llm.providers.openrouter import OpenRouterAdapter
from cloud_dog_llm.providers.registry import ProviderRegistry


def create_provider(config: ProviderConfig) -> ProviderAdapter:
    provider = config.provider_id.lower()
    if provider == "ollama":
        return OllamaAdapter(config)
    if provider == "openrouter":
        return OpenRouterAdapter(config)
    if provider == "anthropic":
        return AnthropicAdapter(config)
    if provider == "openai":
        return OpenAIAdapter(config)
    return OpenAICompatAdapter(config)


def build_provider_registry(configs: list[ProviderConfig]) -> ProviderRegistry:
    registry = ProviderRegistry()
    for cfg in configs:
        registry.register(cfg.provider_id, create_provider(cfg))
    return registry
