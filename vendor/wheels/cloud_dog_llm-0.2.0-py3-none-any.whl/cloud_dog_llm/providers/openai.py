# cloud_dog_llm — OpenAI provider adapter
"""First-party OpenAI adapter built on the OpenAI-compatible base adapter."""

from __future__ import annotations

from cloud_dog_llm.config.models import ProviderConfig
from cloud_dog_llm.providers.openai_compat import OpenAICompatAdapter


class OpenAIAdapter(OpenAICompatAdapter):
    """OpenAI adapter.

    This adapter keeps a dedicated module path for OpenAI while reusing the
    OpenAI-compatible transport implementation.
    """

    def __init__(self, config: ProviderConfig) -> None:
        super().__init__(config)
