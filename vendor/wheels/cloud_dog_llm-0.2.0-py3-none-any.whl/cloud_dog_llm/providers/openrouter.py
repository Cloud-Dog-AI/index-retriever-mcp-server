# cloud_dog_llm — OpenRouter provider adapter
"""OpenRouter adapter built on OpenAI-compatible interface."""

from __future__ import annotations

from cloud_dog_llm.config.models import ProviderConfig
from cloud_dog_llm.providers.openai_compat import OpenAICompatAdapter


class OpenRouterAdapter(OpenAICompatAdapter):
    def __init__(self, config: ProviderConfig) -> None:
        extra = dict(config.extra_headers or {})
        extra.setdefault("HTTP-Referer", "https://cloud-dog.net")
        extra.setdefault("X-Title", "Cloud-Dog AI")
        super().__init__(
            ProviderConfig(
                provider_id=config.provider_id,
                base_url=config.base_url,
                model=config.model,
                api_key=config.api_key,
                timeout_seconds=config.timeout_seconds,
                extra_headers=extra,
            )
        )
