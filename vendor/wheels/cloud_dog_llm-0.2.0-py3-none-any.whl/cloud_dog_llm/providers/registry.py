# cloud_dog_llm — Provider registry
"""Provider adapter registry and lookup."""

from __future__ import annotations

from cloud_dog_llm.providers.base import ProviderAdapter


class ProviderRegistry:
    def __init__(self) -> None:
        self._providers: dict[str, ProviderAdapter] = {}

    def register(self, provider_id: str, adapter: ProviderAdapter) -> None:
        self._providers[provider_id] = adapter

    def get(self, provider_id: str) -> ProviderAdapter:
        if provider_id not in self._providers:
            raise KeyError(f"Provider not registered: {provider_id}")
        return self._providers[provider_id]

    def has(self, provider_id: str) -> bool:
        return provider_id in self._providers

    def list_ids(self) -> list[str]:
        return sorted(self._providers.keys())
