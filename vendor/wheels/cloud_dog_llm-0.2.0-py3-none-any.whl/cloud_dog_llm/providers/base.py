# cloud_dog_llm — Provider adapter interface
"""Abstract base class for pluggable LLM provider adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator

from cloud_dog_llm.domain.models import LLMEvent, LLMRequest, LLMResponse
from cloud_dog_llm.registry.capabilities import CapabilityDescriptor


class ProviderAdapter(ABC):
    @abstractmethod
    async def invoke(self, request: LLMRequest) -> LLMResponse:
        raise NotImplementedError

    @abstractmethod
    async def invoke_stream(self, request: LLMRequest) -> AsyncIterator[LLMEvent]:
        raise NotImplementedError

    @abstractmethod
    async def health(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def capabilities(self) -> CapabilityDescriptor:
        raise NotImplementedError
