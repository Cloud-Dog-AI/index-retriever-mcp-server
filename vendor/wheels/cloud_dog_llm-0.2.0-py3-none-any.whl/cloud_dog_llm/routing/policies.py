# cloud_dog_llm — Routing policies
"""Policy helpers for selecting local/MCP/A2A execution targets."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class RoutingPolicy:
    mcp_prefixes: set[str] = field(default_factory=lambda: {"mcp."})
    a2a_prefixes: set[str] = field(default_factory=lambda: {"a2a."})
    local_prefixes: set[str] = field(default_factory=set)

    def target_for_tool(self, tool_id: str) -> str:
        for prefix in self.mcp_prefixes:
            if tool_id.startswith(prefix):
                return "mcp"
        for prefix in self.a2a_prefixes:
            if tool_id.startswith(prefix):
                return "a2a"
        for prefix in self.local_prefixes:
            if tool_id.startswith(prefix):
                return "local"
        return "local"
