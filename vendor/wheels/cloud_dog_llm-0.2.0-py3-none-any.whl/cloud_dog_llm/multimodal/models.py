# cloud_dog_llm — Multimodal models
"""Typed content-part models for text/image/file payloads."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ContentPartType(str, Enum):
    TEXT = "text"
    IMAGE_URL = "image_url"
    FILE_REF = "file_ref"


@dataclass(frozen=True, slots=True)
class ContentPart:
    type: ContentPartType
    text: str = ""
    image_url: str = ""
    file_ref: str = ""

    def validate(self) -> None:
        if self.type is ContentPartType.TEXT and not self.text:
            raise ValueError("Text content part requires non-empty text")
        if self.type is ContentPartType.IMAGE_URL and not self.image_url:
            raise ValueError("Image content part requires image_url")
        if self.type is ContentPartType.FILE_REF and not self.file_ref:
            raise ValueError("File-ref content part requires file_ref")
