from __future__ import annotations

from cloud_dog_llm.tools.calling import parse_json_tool_call, parse_openai_tool_calls


class ToolCallParser:
    """Unified parser wrapper for provider tool-call formats."""

    @staticmethod
    def from_openai_message(choice_message: dict) -> list:
        return parse_openai_tool_calls(choice_message)

    @staticmethod
    def from_text(text: str):
        return parse_json_tool_call(text)


__all__ = ["parse_json_tool_call", "parse_openai_tool_calls", "ToolCallParser"]
