# cloud_dog_llm — Tool output reducer
"""Reducer for trimming large tool payloads with configurable bounds."""

from __future__ import annotations

from typing import Any


def reduce_output(
    payload: dict[str, Any],
    *,
    max_items: int = 10,
    max_chars: int = 4096,
    fields: list[str] | None = None,
) -> dict[str, Any]:
    out: dict[str, Any] = {}
    keys = fields or list(payload.keys())
    for key in keys[:max_items]:
        if key not in payload:
            continue
        value = payload[key]
        if isinstance(value, str) and len(value) > max_chars:
            out[key] = value[:max_chars]
        else:
            out[key] = value
    return out
