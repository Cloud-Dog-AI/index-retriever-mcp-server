from __future__ import annotations

from typing import Any


def normalize_json_schema(schema: dict[str, Any]) -> dict[str, Any]:
    out = dict(schema)
    out.setdefault("type", "object")
    out.setdefault("properties", {})
    if not isinstance(out["properties"], dict):
        out["properties"] = {}
    return out
