# cloud_dog_llm — Tool executor
"""Single-call and batch tool execution helpers."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from cloud_dog_llm.tools.models import ToolCall, ToolResult
from cloud_dog_llm.tools.pipeline import ToolPipeline

ToolHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class ToolExecutor:
    """Executes tool calls using the shared ToolPipeline implementation."""

    def __init__(self, handlers: dict[str, ToolHandler], max_concurrency: int = 4) -> None:
        self._pipeline = ToolPipeline(handlers=handlers, max_concurrency=max_concurrency)

    async def execute(self, call: ToolCall) -> ToolResult:
        result = await self._pipeline.run_sequential([call])
        return result.results[0]

    async def execute_many(self, calls: list[ToolCall], *, parallel: bool = True) -> list[ToolResult]:
        result = await (self._pipeline.run_parallel(calls) if parallel else self._pipeline.run_sequential(calls))
        return result.results
