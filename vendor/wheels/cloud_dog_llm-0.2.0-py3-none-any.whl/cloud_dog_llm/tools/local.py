from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

LocalToolHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class LocalToolRegistry:
    def __init__(self) -> None:
        self._handlers: dict[str, LocalToolHandler] = {}

    def register(self, tool_id: str, handler: LocalToolHandler) -> None:
        self._handlers[tool_id] = handler

    async def execute(self, tool_id: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if tool_id not in self._handlers:
            raise KeyError(f"Local tool not found: {tool_id}")
        return await self._handlers[tool_id](arguments)
