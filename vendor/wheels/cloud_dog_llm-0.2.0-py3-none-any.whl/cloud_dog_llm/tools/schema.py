# cloud_dog_llm — Tool schema helpers
"""Compatibility module for tool schema handling."""

from __future__ import annotations

from typing import Any

from cloud_dog_llm.tools.schemas import normalize_json_schema


def validate_arguments(schema: dict[str, Any], args: dict[str, Any]) -> tuple[bool, str]:
    norm = normalize_json_schema(schema)
    required = norm.get("required", [])
    if isinstance(required, list):
        for key in required:
            if key not in args:
                return False, f"Missing required argument: {key}"
    properties = norm.get("properties", {})
    if isinstance(properties, dict):
        for key in args:
            if properties and key not in properties:
                return False, f"Unknown argument: {key}"
    return True, "ok"
