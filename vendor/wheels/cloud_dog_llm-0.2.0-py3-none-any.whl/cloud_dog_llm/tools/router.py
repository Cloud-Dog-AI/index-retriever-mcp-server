# cloud_dog_llm — Tool router
"""Policy-light unified tool router for local handlers."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from cloud_dog_llm.security.policies import GovernancePolicy
from cloud_dog_llm.tools.models import ToolCall, ToolDef, ToolResult

ToolHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class ToolRouter:
    def __init__(self, policy: GovernancePolicy | None = None) -> None:
        self._defs: dict[str, ToolDef] = {}
        self._handlers: dict[str, ToolHandler] = {}
        self._policy = policy or GovernancePolicy()

    def register(self, tool_def: ToolDef, handler: ToolHandler) -> None:
        self._defs[tool_def.tool_id] = tool_def
        self._handlers[tool_def.tool_id] = handler

    async def route(self, call: ToolCall) -> ToolResult:
        if not self._policy.tool_allowed(call.tool_id):
            return ToolResult(tool_id=call.tool_id, success=False, output={}, error="Tool blocked by policy")
        if call.tool_id not in self._handlers:
            return ToolResult(tool_id=call.tool_id, success=False, output={}, error="Tool not registered")
        try:
            out = await self._handlers[call.tool_id](call.arguments)
            return ToolResult(tool_id=call.tool_id, success=True, output=out)
        except Exception as exc:  # noqa: BLE001
            return ToolResult(tool_id=call.tool_id, success=False, output={}, error=str(exc))

    def available_tools(self) -> list[ToolDef]:
        return list(self._defs.values())
