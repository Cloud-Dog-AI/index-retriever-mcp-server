# cloud_dog_llm — Tool models
"""Tool definition and call/result models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from cloud_dog_llm.domain.enums import ExecutionMode


@dataclass(frozen=True, slots=True)
class ToolDef:
    tool_id: str
    name: str
    description: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any] = field(default_factory=dict)
    execution_mode: ExecutionMode = ExecutionMode.LOCAL


@dataclass(frozen=True, slots=True)
class ToolCall:
    tool_id: str
    name: str
    arguments: dict[str, Any]


@dataclass(frozen=True, slots=True)
class ToolResult:
    tool_id: str
    success: bool
    output: dict[str, Any]
    error: str = ""
