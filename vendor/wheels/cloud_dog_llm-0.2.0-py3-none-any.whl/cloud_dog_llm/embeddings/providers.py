# cloud_dog_llm — Embedding provider wiring
"""Helpers to resolve embedding providers from LLM adapters."""

from __future__ import annotations

from cloud_dog_llm.embeddings.base import EmbeddingProvider


def provider_from_adapter(adapter) -> EmbeddingProvider:
    if not hasattr(adapter, "embeddings"):
        raise TypeError("Adapter does not implement embeddings()")
    return adapter
