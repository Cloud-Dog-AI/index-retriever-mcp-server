# cloud_dog_llm — Embedding provider interface
"""Embedding provider protocol."""

from __future__ import annotations

from typing import Protocol


class EmbeddingProvider(Protocol):
    async def embeddings(self, texts: list[str], *, model: str | None = None) -> list[list[float]]: ...

    async def dimensions(self, *, model: str | None = None) -> int | None:
        _ = model
        return None
