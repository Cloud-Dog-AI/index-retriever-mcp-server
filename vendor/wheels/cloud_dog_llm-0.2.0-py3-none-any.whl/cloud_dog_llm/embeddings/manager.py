# cloud_dog_llm — Embedding manager
"""Unified embedding manager over a provider adapter."""

from __future__ import annotations

from cloud_dog_llm.embeddings.base import EmbeddingProvider


class EmbeddingManager:
    def __init__(self, provider: EmbeddingProvider, model: str | None = None) -> None:
        self._provider = provider
        self._model = model

    async def generate_embedding(self, text: str) -> list[float]:
        return (await self._provider.embeddings([text], model=self._model))[0]

    async def generate_embeddings(self, texts: list[str]) -> list[list[float]]:
        return await self._provider.embeddings(texts, model=self._model)
