from __future__ import annotations

from cloud_dog_llm.providers.openai_compat import OpenAICompatAdapter


class OpenAICompatEmbeddingProvider:
    def __init__(self, adapter: OpenAICompatAdapter) -> None:
        self._adapter = adapter

    async def embeddings(self, texts: list[str], *, model: str | None = None) -> list[list[float]]:
        return await self._adapter.embeddings(texts, model=model)
