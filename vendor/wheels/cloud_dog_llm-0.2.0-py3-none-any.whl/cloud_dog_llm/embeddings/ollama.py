from __future__ import annotations

from cloud_dog_llm.providers.ollama import OllamaAdapter


class OllamaEmbeddingProvider:
    def __init__(self, adapter: OllamaAdapter) -> None:
        self._adapter = adapter

    async def embeddings(self, texts: list[str], *, model: str | None = None) -> list[list[float]]:
        return await self._adapter.embeddings(texts, model=model)
