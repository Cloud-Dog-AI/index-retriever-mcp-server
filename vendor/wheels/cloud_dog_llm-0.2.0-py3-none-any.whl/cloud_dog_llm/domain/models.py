# cloud_dog_llm — Domain models
"""Portable request/response/session/tool models for PS-50."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from cloud_dog_llm.domain.enums import EventType, FinishReason


@dataclass(frozen=True, slots=True)
class SessionContext:
    session_id: str
    correlation_id: str
    conversation_id: str | None = None
    user_id: str | None = None
    tenant_id: str | None = None


@dataclass(frozen=True, slots=True)
class Message:
    role: str
    content: str | list[dict[str, Any]]


@dataclass(frozen=True, slots=True)
class LLMRequest:
    messages: list[Message]
    model: str | None = None
    provider_id: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    stream: bool = False
    params: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class Usage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


@dataclass(frozen=True, slots=True)
class LLMResponse:
    request_id: str
    provider_id: str
    model_id: str
    content: str
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    finish_reason: FinishReason = FinishReason.STOP
    usage: Usage = field(default_factory=Usage)
    timing: dict[str, float] = field(default_factory=dict)
    raw_provider_response: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class LLMEvent:
    type: EventType
    request_id: str
    provider_id: str
    model_id: str
    text: str = ""
    error: str = ""
