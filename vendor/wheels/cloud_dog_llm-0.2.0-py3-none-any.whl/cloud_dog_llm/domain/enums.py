# cloud_dog_llm — Domain enums
"""Core enums for the PS-50 domain model."""

from __future__ import annotations

from enum import Enum


class EventType(str, Enum):
    RESPONSE_STARTED = "response_started"
    DELTA_TEXT = "delta_text"
    DELTA_TOOL_CALL = "delta_tool_call"
    TOOL_CALL_STARTED = "tool_call_started"
    TOOL_CALL_RESULT = "tool_call_result"
    RESPONSE_COMPLETED = "response_completed"
    RESPONSE_ERROR = "response_error"


class FinishReason(str, Enum):
    STOP = "stop"
    LENGTH = "length"
    TOOL_CALLS = "tool_calls"
    ERROR = "error"


class ExecutionMode(str, Enum):
    LOCAL = "local"
    REMOTE = "remote"
    MCP = "mcp"
    A2A = "a2a"
