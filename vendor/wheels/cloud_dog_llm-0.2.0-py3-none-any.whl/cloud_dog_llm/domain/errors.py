# cloud_dog_llm — Domain errors
"""Portable error taxonomy for provider-agnostic callers."""

from __future__ import annotations


class LLMError(Exception):
    """Base error for all cloud_dog_llm failures."""

    def __init__(self, message: str, *, retryable: bool = False) -> None:
        super().__init__(message)
        self.retryable = retryable


class AuthError(LLMError):
    pass


class RateLimitError(LLMError):
    def __init__(self, message: str) -> None:
        super().__init__(message, retryable=True)


class TimeoutError(LLMError):
    def __init__(self, message: str) -> None:
        super().__init__(message, retryable=True)


class ProviderUnavailableError(LLMError):
    def __init__(self, message: str) -> None:
        super().__init__(message, retryable=True)


class InvalidRequestError(LLMError):
    pass


class StreamingProtocolError(LLMError):
    pass


class ToolExecutionError(LLMError):
    pass


class CancelledError(LLMError):
    pass
