# cloud_dog_llm — Role-based access control helpers
"""Simple RBAC checks for tools and providers."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class RBACPolicy:
    """Maps roles to allowed tools/providers."""

    role_tools: dict[str, set[str]] = field(default_factory=dict)
    role_providers: dict[str, set[str]] = field(default_factory=dict)

    def can_use_tool(self, role: str, tool_id: str) -> bool:
        allowed = self.role_tools.get(role, set())
        return not allowed or tool_id in allowed

    def can_use_provider(self, role: str, provider_id: str) -> bool:
        allowed = self.role_providers.get(role, set())
        return not allowed or provider_id in allowed


__all__ = ["RBACPolicy"]
