from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class ToolsPolicy:
    allow: set[str] = field(default_factory=set)
    deny: set[str] = field(default_factory=set)

    def allowed(self, tool_id: str) -> bool:
        if tool_id in self.deny:
            return False
        if self.allow and tool_id not in self.allow:
            return False
        return True
