# cloud_dog_llm — Secret/content redaction
"""Redaction hooks for logs and diagnostics."""

from __future__ import annotations

import re

_SECRET_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9_-]{8,}"),
    re.compile(r"Bearer\s+[A-Za-z0-9._-]{8,}", flags=re.IGNORECASE),
    re.compile(r"(api[_-]?key\s*[=:]\s*)[^\s,;]+", flags=re.IGNORECASE),
]


def redact_secrets(text: str) -> str:
    out = text
    for pattern in _SECRET_PATTERNS:
        out = pattern.sub(lambda m: f"{m.group(1)}***" if m.lastindex else "***", out)
    return out
