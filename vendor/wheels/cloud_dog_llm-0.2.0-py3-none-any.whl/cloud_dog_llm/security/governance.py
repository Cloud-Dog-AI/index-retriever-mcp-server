from __future__ import annotations

from cloud_dog_llm.security.policies import GovernancePolicy


def enforce_request(policy: GovernancePolicy, *, provider_id: str, prompt: str, max_tokens: int | None) -> None:
    if not policy.provider_allowed(provider_id):
        raise ValueError(f"Provider not allowed: {provider_id}")
    if not policy.validate_prompt(prompt):
        raise ValueError("Prompt exceeds governance max_prompt_chars")
    if max_tokens is not None and max_tokens > policy.max_output_tokens:
        raise ValueError("Requested max_tokens exceeds governance max_output_tokens")


__all__ = ["GovernancePolicy", "enforce_request"]
