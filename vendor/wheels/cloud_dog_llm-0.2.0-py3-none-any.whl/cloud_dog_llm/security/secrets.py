# cloud_dog_llm — Secret detection helpers
"""Secret detection and payload redaction utilities."""

from __future__ import annotations

from typing import Any

from cloud_dog_llm.security.redaction import redact_secrets


def contains_secret(value: str) -> bool:
    return redact_secrets(value) != value


def redact_payload(payload: dict[str, Any]) -> dict[str, Any]:
    redacted: dict[str, Any] = {}
    for key, value in payload.items():
        if isinstance(value, str):
            redacted[key] = redact_secrets(value)
        else:
            redacted[key] = value
    return redacted
