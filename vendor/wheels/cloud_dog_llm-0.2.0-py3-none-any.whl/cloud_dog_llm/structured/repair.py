# cloud_dog_llm — Structured repair loop
"""Bounded retries for recovering valid JSON payloads."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from cloud_dog_llm.structured.extractor import extract_json


def repair_json(
    initial_text: str,
    repair_fn: Callable[[str], str],
    *,
    max_retries: int = 2,
) -> dict[str, Any] | None:
    payload = extract_json(initial_text)
    if payload is not None:
        return payload
    text = initial_text
    for _ in range(max_retries):
        text = repair_fn(text)
        payload = extract_json(text)
        if payload is not None:
            return payload
    return None
