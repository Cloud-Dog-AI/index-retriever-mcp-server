# cloud_dog_llm — Structured schema model
"""Schema helpers for structured-output validation."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class StructuredSchema:
    """Minimal schema model used by structured validator helpers."""

    required: set[str] = field(default_factory=set)
    optional: set[str] = field(default_factory=set)
    allow_extra_keys: bool = False

    @classmethod
    def from_json_schema(cls, schema: dict) -> "StructuredSchema":
        properties = schema.get("properties", {}) if isinstance(schema, dict) else {}
        required_raw = schema.get("required", []) if isinstance(schema, dict) else []
        keys = set(properties.keys()) if isinstance(properties, dict) else set()
        required = {k for k in required_raw if isinstance(k, str)}
        optional = keys - required
        allow_extra = bool(schema.get("additionalProperties", False)) if isinstance(schema, dict) else False
        return cls(required=required, optional=optional, allow_extra_keys=allow_extra)


__all__ = ["StructuredSchema"]
