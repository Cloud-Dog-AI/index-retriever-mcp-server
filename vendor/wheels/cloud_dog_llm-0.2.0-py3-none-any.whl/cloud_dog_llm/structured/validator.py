# cloud_dog_llm — Structured validator
"""Validation helpers for parsed structured output."""

from __future__ import annotations

from cloud_dog_llm.structured.schema import StructuredSchema


def validate_payload(payload: dict, schema: StructuredSchema) -> tuple[bool, str]:
    keys = set(payload.keys()) if isinstance(payload, dict) else set()
    missing = sorted(schema.required - keys)
    if missing:
        return False, f"Missing required keys: {', '.join(missing)}"

    if not schema.allow_extra_keys:
        allowed = schema.required | schema.optional
        extras = sorted(keys - allowed)
        if extras:
            return False, f"Unexpected keys: {', '.join(extras)}"
    return True, "ok"


__all__ = ["validate_payload"]
