# cloud_dog_llm — Structured parser
"""Structured payload parser with strict/lenient modes."""

from __future__ import annotations

from typing import Any

from cloud_dog_llm.structured.extractor import extract_json


def parse_structured_payload(text: str, *, strict: bool = False) -> dict[str, Any] | None:
    payload = extract_json(text)
    if payload is not None:
        return payload
    if strict:
        raise ValueError("No structured JSON payload found")
    return None
