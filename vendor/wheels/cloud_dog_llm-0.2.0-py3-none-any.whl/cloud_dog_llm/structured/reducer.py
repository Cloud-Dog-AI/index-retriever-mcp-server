from __future__ import annotations

from typing import Any


def reduce_structured_payload(payload: dict[str, Any], *, max_chars: int = 4096) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in payload.items():
        if isinstance(value, str) and len(value) > max_chars:
            out[key] = value[:max_chars]
        else:
            out[key] = value
    return out
