# cloud_dog_llm — Queue-aware availability gating
"""Determine model availability from queue depth and rate-limit state."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class AvailabilityState(str, Enum):
    AVAILABLE = "available"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"


@dataclass(frozen=True, slots=True)
class AvailabilityStatus:
    model_id: str
    state: AvailabilityState
    queue_depth: int
    queue_threshold: int
    rate_limit_remaining: int | None = None


class QueueAwareAvailabilityGate:
    def __init__(
        self,
        *,
        default_threshold: int = 100,
        degraded_ratio: float = 0.8,
        model_thresholds: dict[str, int] | None = None,
    ) -> None:
        self._default_threshold = max(1, int(default_threshold))
        self._degraded_ratio = min(max(degraded_ratio, 0.1), 0.99)
        self._thresholds = dict(model_thresholds or {})
        self._queue_depths: dict[str, int] = {}

    def set_threshold(self, model_id: str, threshold: int) -> None:
        self._thresholds[model_id] = max(1, int(threshold))

    def update_queue_depth(self, model_id: str, depth: int) -> None:
        self._queue_depths[model_id] = max(0, int(depth))

    def check_availability(self, model_id: str, *, rate_limit_remaining: int | None = None) -> AvailabilityStatus:
        threshold = self._thresholds.get(model_id, self._default_threshold)
        depth = self._queue_depths.get(model_id, 0)

        if rate_limit_remaining is not None and rate_limit_remaining <= 0:
            return AvailabilityStatus(
                model_id=model_id,
                state=AvailabilityState.UNAVAILABLE,
                queue_depth=depth,
                queue_threshold=threshold,
                rate_limit_remaining=rate_limit_remaining,
            )

        degraded_at = max(1, int(threshold * self._degraded_ratio))
        if depth >= threshold:
            state = AvailabilityState.UNAVAILABLE
        elif depth >= degraded_at:
            state = AvailabilityState.DEGRADED
        else:
            state = AvailabilityState.AVAILABLE

        return AvailabilityStatus(
            model_id=model_id,
            state=state,
            queue_depth=depth,
            queue_threshold=threshold,
            rate_limit_remaining=rate_limit_remaining,
        )
