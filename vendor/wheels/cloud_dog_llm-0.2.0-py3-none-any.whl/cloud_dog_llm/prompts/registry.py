# cloud_dog_llm — Prompt registry
"""In-memory prompt template registry with versioned keys."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PromptTemplate:
    name: str
    version: str
    template: str


class PromptRegistry:
    def __init__(self) -> None:
        self._templates: dict[tuple[str, str], PromptTemplate] = {}

    def register(self, name: str, version: str, template: str) -> None:
        self._templates[(name, version)] = PromptTemplate(name=name, version=version, template=template)

    def get(self, name: str, version: str) -> PromptTemplate:
        key = (name, version)
        if key not in self._templates:
            raise KeyError(f"Prompt not found: {name}@{version}")
        return self._templates[key]
