# cloud_dog_llm — Prompt template model
"""Versioned prompt template structure with deterministic keying."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PromptTemplateVersion:
    name: str
    version: str
    template: str

    @property
    def key(self) -> str:
        return f"{self.name}@{self.version}"
