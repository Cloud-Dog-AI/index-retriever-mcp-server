# cloud_dog_llm — Prompt rendering
"""Deterministic Jinja2 prompt rendering helpers."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any

from jinja2 import Environment, StrictUndefined


@dataclass(frozen=True, slots=True)
class RenderedPrompt:
    text: str
    sha256: str


def render_template(template: str, variables: dict[str, Any]) -> RenderedPrompt:
    env = Environment(undefined=StrictUndefined, autoescape=False, trim_blocks=True, lstrip_blocks=True)
    text = env.from_string(template).render(**variables)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return RenderedPrompt(text=text, sha256=digest)
