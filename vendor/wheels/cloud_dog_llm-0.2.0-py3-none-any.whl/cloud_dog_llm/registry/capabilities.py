# cloud_dog_llm — Capability descriptor
"""Model capability descriptors used by registry and adapters."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CapabilityDescriptor:
    provider_id: str
    model_id: str
    chat: bool = True
    streaming: bool = True
    tool_calling: bool = False
    structured_output: bool = False
    vision: bool = False
    json_mode: bool = False
    embeddings: bool = False
    max_tokens: int | None = None
    context_window: int = 0
    supports_streaming: bool | None = None

    def __post_init__(self) -> None:
        if self.supports_streaming is None:
            object.__setattr__(self, "supports_streaming", self.streaming)
        else:
            object.__setattr__(self, "streaming", bool(self.supports_streaming))
