# cloud_dog_llm — Model registry
"""Simple registry for model capability descriptors."""

from __future__ import annotations

from cloud_dog_llm.registry.capabilities import CapabilityDescriptor


class ModelRegistry:
    def __init__(self) -> None:
        self._models: dict[str, CapabilityDescriptor] = {}

    def register(self, model_id: str, descriptor: CapabilityDescriptor) -> None:
        self._models[model_id] = descriptor

    def get(self, model_id: str) -> CapabilityDescriptor | None:
        return self._models.get(model_id)

    def get_capabilities(self, model_id: str) -> CapabilityDescriptor:
        found = self._models.get(model_id)
        if found is not None:
            return found
        return CapabilityDescriptor(
            provider_id="unknown",
            model_id=model_id,
            chat=False,
            streaming=False,
            tool_calling=False,
            structured_output=False,
            vision=False,
            json_mode=False,
            embeddings=False,
            max_tokens=None,
            context_window=0,
        )

    def validate_params(self, model_id: str, params: dict[str, object]) -> list[str]:
        caps = self.get_capabilities(model_id)
        errors: list[str] = []
        if "response_format" in params and not (caps.structured_output or caps.json_mode):
            errors.append("response_format not supported by model")
        if "tools" in params and not caps.tool_calling:
            errors.append("tool calling not supported by model")
        return errors

    def all(self) -> list[CapabilityDescriptor]:
        return list(self._models.values())
