# cloud_dog_llm — Artefact models
"""Artefact metadata models exposed as a compatibility module."""

from __future__ import annotations

from cloud_dog_llm.artefacts.store import Artefact

__all__ = ["Artefact"]
