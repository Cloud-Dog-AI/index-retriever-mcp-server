from __future__ import annotations

from abc import ABC, abstractmethod

from cloud_dog_llm.artefacts.store import Artefact


class ArtefactStore(ABC):
    @abstractmethod
    def put(self, content: bytes, *, filename: str, mime_type: str) -> Artefact:
        raise NotImplementedError

    @abstractmethod
    def get(self, artefact_id: str) -> tuple[Artefact, bytes] | None:
        raise NotImplementedError
