from __future__ import annotations

from cloud_dog_llm.artefacts.store import InMemoryArtefactStore


class MemoryArtefactStore(InMemoryArtefactStore):
    """In-memory store with convenience maintenance helpers."""

    def list_ids(self) -> list[str]:
        return sorted(self._meta.keys())  # type: ignore[attr-defined]

    def purge_expired(self) -> int:
        now_ids = list(self.list_ids())
        removed = 0
        for artefact_id in now_ids:
            loaded = self.get(artefact_id)
            if loaded is None:
                self._meta.pop(artefact_id, None)  # type: ignore[attr-defined]
                self._data.pop(artefact_id, None)  # type: ignore[attr-defined]
                removed += 1
        return removed
