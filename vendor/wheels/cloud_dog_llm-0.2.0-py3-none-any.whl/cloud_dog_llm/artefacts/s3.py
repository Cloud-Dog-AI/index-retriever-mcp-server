from __future__ import annotations

from pathlib import Path

from cloud_dog_llm.artefacts.local import LocalArtefactStore


class S3ArtefactStore(LocalArtefactStore):
    """S3-compatible store surface backed by local filesystem in tests.

    The public API mirrors a bucket/key style without introducing a hard
    runtime dependency on boto3 for local and unit-test execution.
    """

    def __init__(self, bucket: str, prefix: str = "", root: str = ".artefacts_s3") -> None:
        self.bucket = bucket
        self.prefix = prefix.strip("/")
        path = Path(root) / bucket
        if self.prefix:
            path = path / self.prefix
        super().__init__(str(path))
