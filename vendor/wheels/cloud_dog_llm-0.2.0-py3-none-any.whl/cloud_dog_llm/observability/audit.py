from __future__ import annotations

import time
from typing import Any

from cloud_dog_llm.observability.redaction import redact_payload


def build_audit_event(event_type: str, correlation_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "event_type": event_type,
        "correlation_id": correlation_id,
        "timestamp": time.time(),
        "payload": redact_payload(payload),
    }
