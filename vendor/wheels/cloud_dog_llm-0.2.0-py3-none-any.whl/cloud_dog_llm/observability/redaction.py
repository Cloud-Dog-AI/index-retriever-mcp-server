from __future__ import annotations

from cloud_dog_llm.security.redaction import redact_secrets


def redact_payload(payload: dict) -> dict:
    out: dict = {}
    for key, value in payload.items():
        if isinstance(value, str):
            out[key] = redact_secrets(value)
        elif isinstance(value, dict):
            out[key] = redact_payload(value)
        elif isinstance(value, list):
            out[key] = [
                redact_payload(v) if isinstance(v, dict) else redact_secrets(v) if isinstance(v, str) else v
                for v in value
            ]
        else:
            out[key] = value
    return out


__all__ = ["redact_secrets", "redact_payload"]
