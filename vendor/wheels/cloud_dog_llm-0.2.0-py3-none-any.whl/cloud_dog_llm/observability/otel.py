from __future__ import annotations

import time
from contextlib import contextmanager


def otel_enabled() -> bool:
    try:
        import opentelemetry  # noqa: F401

        return True
    except Exception:  # noqa: BLE001
        return False


@contextmanager
def span(name: str, *, attributes: dict[str, str] | None = None):
    """No-op span compatible with optional OTEL instrumentation."""
    started = time.perf_counter()
    _ = (name, attributes)
    try:
        yield {"name": name, "started": started}
    finally:
        _elapsed = (time.perf_counter() - started) * 1000
        _ = _elapsed
