from __future__ import annotations

import time


class MetricsHooks:
    def __init__(self) -> None:
        self.counts: dict[str, int] = {}
        self.timings_ms: dict[str, list[float]] = {}

    def inc(self, key: str) -> None:
        self.counts[key] = self.counts.get(key, 0) + 1

    def observe_ms(self, key: str, value_ms: float) -> None:
        self.timings_ms.setdefault(key, []).append(float(value_ms))

    def avg_ms(self, key: str) -> float:
        values = self.timings_ms.get(key, [])
        if not values:
            return 0.0
        return sum(values) / len(values)

    def timed(self, key: str):
        start = time.perf_counter()

        def done() -> float:
            elapsed = (time.perf_counter() - start) * 1000
            self.observe_ms(key, elapsed)
            return elapsed

        return done
