# cloud_dog_llm — Observability logging helpers
"""Structured logging helpers for request/response lifecycle events."""

from __future__ import annotations

from typing import Any

from cloud_dog_llm.security.redaction import redact_secrets


def build_log_payload(event: str, *, correlation_id: str, fields: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = {
        "event": event,
        "correlation_id": correlation_id,
    }
    if fields:
        redacted = {k: redact_secrets(str(v)) if isinstance(v, str) else v for k, v in fields.items()}
        payload.update(redacted)
    return payload
