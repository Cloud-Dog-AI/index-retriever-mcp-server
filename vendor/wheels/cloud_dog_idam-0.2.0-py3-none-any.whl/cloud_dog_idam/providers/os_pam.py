# cloud_dog_idam — OS/PAM provider
"""Authenticate local system users via Linux PAM."""

from __future__ import annotations

from cloud_dog_idam.domain.errors import AuthenticationError
from cloud_dog_idam.domain.models import AuthRequest, AuthResult, User
from cloud_dog_idam.providers.base import AuthProvider

try:
    import pam  # type: ignore
except ImportError:  # pragma: no cover
    pam = None


class OSPAMProvider(AuthProvider):
    def __init__(self, *, service: str = "login") -> None:
        self._service = service

    async def supports(self, auth_type: str) -> bool:
        return auth_type == "os_pam"

    async def authenticate(self, request: AuthRequest) -> AuthResult:
        if pam is None:
            raise AuthenticationError("python-pam is not installed")
        client = pam.pam()
        ok = client.authenticate(
            request.principal, request.secret, service=self._service
        )
        if not ok:
            raise AuthenticationError("PAM authentication failed")
        return AuthResult(
            user=User(username=request.principal, email=f"{request.principal}@local")
        )
