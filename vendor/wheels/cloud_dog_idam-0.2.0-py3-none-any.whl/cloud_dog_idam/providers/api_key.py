# cloud_dog_idam — API key provider
"""Authenticate requests by API key."""

from __future__ import annotations

from cloud_dog_idam.api_keys.manager import APIKeyManager
from cloud_dog_idam.domain.errors import AuthenticationError
from cloud_dog_idam.domain.models import AuthRequest, AuthResult, User
from cloud_dog_idam.providers.base import AuthProvider


class APIKeyProvider(AuthProvider):
    def __init__(self, manager: APIKeyManager, user_lookup) -> None:
        self._manager = manager
        self._user_lookup = user_lookup

    async def supports(self, auth_type: str) -> bool:
        return auth_type == "api_key"

    async def authenticate(self, request: AuthRequest) -> AuthResult:
        key = self._manager.validate(request.secret)
        if key is None:
            raise AuthenticationError("Invalid API key")
        user = self._user_lookup(key.owner_user_id)
        if user is None:
            user = User(
                user_id=key.owner_user_id, username="system", is_system_user=True
            )
        return AuthResult(user=user)
