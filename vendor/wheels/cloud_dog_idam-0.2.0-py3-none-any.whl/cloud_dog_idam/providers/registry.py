# cloud_dog_idam — Provider registry
"""Authentication provider registration, ordering, and dispatch."""

from __future__ import annotations

import sys
from dataclasses import dataclass

from cloud_dog_idam.domain.errors import AuthenticationError
from cloud_dog_idam.domain.models import AuthRequest, AuthResult
from cloud_dog_idam.providers.base import AuthProvider


@dataclass(slots=True)
class _ProviderEntry:
    priority: int
    order: int
    provider: AuthProvider


class ProviderRegistry:
    def __init__(self) -> None:
        self._providers: list[_ProviderEntry] = []
        self._next_order = 0

    def register(self, provider: AuthProvider, priority: int = 100) -> None:
        self._providers.append(
            _ProviderEntry(priority=priority, order=self._next_order, provider=provider)
        )
        self._next_order += 1
        self._providers.sort(key=lambda item: (item.priority, item.order))

    def deregister(self, auth_type: str) -> int:
        before = len(self._providers)
        self._providers = [
            item
            for item in self._providers
            if getattr(item.provider, "_auth_type", None) != auth_type
        ]
        return before - len(self._providers)

    def list_providers(self) -> list[tuple[str, str]]:
        listing: list[tuple[str, str]] = []
        for item in self._providers:
            auth_type = getattr(item.provider, "_auth_type", "unknown")
            listing.append((str(auth_type), item.provider.__class__.__name__))
        return listing

    async def authenticate(self, request: AuthRequest) -> AuthResult:
        for item in self._providers:
            provider = item.provider
            if await provider.supports(request.auth_type):
                print(
                    f"ProviderRegistry selected {provider.__class__.__name__}"
                    f" for auth_type={request.auth_type}",
                    file=sys.stderr,
                )
                return await provider.authenticate(request)
        raise AuthenticationError(f"No provider supports auth_type={request.auth_type}")
