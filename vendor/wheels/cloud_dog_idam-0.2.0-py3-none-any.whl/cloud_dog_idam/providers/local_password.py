# cloud_dog_idam — Local password provider
"""Local username/password authentication using Argon2id."""

from __future__ import annotations

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

from cloud_dog_idam.domain.errors import AuthenticationError
from cloud_dog_idam.domain.models import AuthRequest, AuthResult, User
from cloud_dog_idam.domain.enums import UserStatus
from cloud_dog_idam.providers.base import AuthProvider


class LocalPasswordProvider(AuthProvider):
    def __init__(self, user_lookup, *, password_field: str = "password_hash") -> None:
        self._lookup = user_lookup
        self._password_field = password_field
        self._hasher = PasswordHasher()

    def hash_password(self, raw_password: str) -> str:
        return self._hasher.hash(raw_password)

    async def supports(self, auth_type: str) -> bool:
        return auth_type == "local_password"

    async def authenticate(self, request: AuthRequest) -> AuthResult:
        user = self._lookup(request.principal)
        if user is None:
            raise AuthenticationError("Unknown user")
        if user.status in {UserStatus.DISABLED, UserStatus.LOCKED}:
            raise AuthenticationError("User disabled or locked")
        password_hash = getattr(user, self._password_field, "")
        try:
            self._hasher.verify(password_hash, request.secret)
        except VerifyMismatchError as exc:
            raise AuthenticationError("Invalid credentials") from exc
        return AuthResult(user=user)


class LocalUser(User):
    password_hash: str = ""
