# cloud_dog_idam — provider exports
"""Provider and browser-flow exports for application embedding."""

from .api_key import APIKeyProvider
from .api_key_only import APIKeyOnlyProvider
from .base import AuthProvider
from .browser_automation import (
    BrowserAutomationError,
    BrowserCredentials,
    BrowserFlowResult,
    InteractiveAuthStart,
    OIDCBrowserAutomation,
)
from .ldap import LDAPProvider
from .local_password import LocalPasswordProvider
from .oidc import (
    Auth0Provider,
    BasicOIDCProvider,
    GoogleProvider,
    KeycloakProvider,
    OIDCAuthContext,
    OIDCAuthorizationSession,
)
from .os_pam import OSPAMProvider
from .registry import ProviderRegistry
from .saml import SAMLConfig, SAMLProvider

__all__ = [
    "APIKeyProvider",
    "APIKeyOnlyProvider",
    "Auth0Provider",
    "AuthProvider",
    "BasicOIDCProvider",
    "BrowserAutomationError",
    "BrowserCredentials",
    "BrowserFlowResult",
    "GoogleProvider",
    "InteractiveAuthStart",
    "KeycloakProvider",
    "LDAPProvider",
    "LocalPasswordProvider",
    "OIDCAuthContext",
    "OIDCAuthorizationSession",
    "OIDCBrowserAutomation",
    "OSPAMProvider",
    "ProviderRegistry",
    "SAMLConfig",
    "SAMLProvider",
]
