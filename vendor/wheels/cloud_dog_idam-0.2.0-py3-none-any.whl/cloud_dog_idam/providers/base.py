# cloud_dog_idam — Provider interface
"""Authentication provider base interface."""

from __future__ import annotations

from abc import ABC, abstractmethod

from cloud_dog_idam.domain.models import AuthRequest, AuthResult


class AuthProvider(ABC):
    @abstractmethod
    async def authenticate(self, request: AuthRequest) -> AuthResult:
        raise NotImplementedError

    @abstractmethod
    async def supports(self, auth_type: str) -> bool:
        raise NotImplementedError
