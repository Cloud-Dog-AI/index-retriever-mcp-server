# cloud_dog_idam — Domain models
"""Canonical domain models for users, roles, groups, keys, and auth requests."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from cloud_dog_idam.domain.enums import ProviderType, UserStatus


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class User:
    user_id: str = field(default_factory=lambda: str(uuid4()))
    username: str = ""
    email: str = ""
    display_name: str = ""
    status: UserStatus = UserStatus.ACTIVE
    role: str = "viewer"
    is_system_user: bool = False
    tenant_id: str | None = None
    password_hash: str = ""
    force_password_change: bool = False
    created_at: datetime = field(default_factory=_utcnow)
    updated_at: datetime = field(default_factory=_utcnow)


@dataclass(slots=True)
class Group:
    group_id: str = field(default_factory=lambda: str(uuid4()))
    name: str = ""
    description: str = ""
    tenant_id: str | None = None


@dataclass(slots=True)
class Role:
    role_id: str = field(default_factory=lambda: str(uuid4()))
    name: str = ""
    description: str = ""
    permissions: set[str] = field(default_factory=set)


@dataclass(slots=True)
class ApiKey:
    api_key_id: str = field(default_factory=lambda: str(uuid4()))
    owner_user_id: str = ""
    key_prefix: str = "cd_"
    key_hash: str = ""
    status: str = "active"
    expires_at: datetime | None = None


@dataclass(slots=True)
class IdentityLink:
    identity_id: str = field(default_factory=lambda: str(uuid4()))
    user_id: str = ""
    provider_type: ProviderType = ProviderType.OIDC
    provider_id: str = ""
    subject: str = ""
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Policy:
    policy_id: str = field(default_factory=lambda: str(uuid4()))
    policy_type: str = ""
    config_json: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AuthRequest:
    auth_type: str
    principal: str = ""
    secret: str = ""
    bearer_token: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class AuthResult:
    user: User
    identity_link: IdentityLink | None = None
    claims: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class TokenPair:
    access_token: str
    refresh_token: str | None
    token_type: str = "Bearer"
    expires_in: int = 3600
