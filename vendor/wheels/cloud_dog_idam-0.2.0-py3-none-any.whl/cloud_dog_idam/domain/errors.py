# cloud_dog_idam — Domain errors
"""Portable exception taxonomy for IDAM operations."""

from __future__ import annotations


class IDAMError(Exception):
    """Base exception for cloud_dog_idam."""


class AuthenticationError(IDAMError):
    """Authentication failed."""


class AuthorisationError(IDAMError):
    """Authorisation failed."""


class ValidationError(IDAMError):
    """Input validation failed."""


class TokenError(IDAMError):
    """Token issue/verification error."""
