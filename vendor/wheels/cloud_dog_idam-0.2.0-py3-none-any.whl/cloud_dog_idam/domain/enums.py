# cloud_dog_idam — Domain enums
"""Domain enums for status and provider handling."""

from __future__ import annotations

from enum import Enum


class UserStatus(str, Enum):
    INITIALISING = "initialising"
    ACTIVE = "active"
    DISABLED = "disabled"
    LOCKED = "locked"
    PENDING_APPROVAL = "pending_approval"


class ProviderType(str, Enum):
    LOCAL_PASSWORD = "local_password"
    API_KEY = "api_key"
    OIDC = "oidc"
    LDAP = "ldap"
    OS_PAM = "os_pam"
    SAML = "saml"


class ProvisioningMode(str, Enum):
    MANUAL = "manual"
    JIT = "jit"
    SYNC = "sync"
