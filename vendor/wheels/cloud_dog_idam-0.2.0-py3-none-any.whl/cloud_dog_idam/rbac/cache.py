# cloud_dog_idam — RBAC cache
"""Simple TTL cache for effective role and permission sets."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone


@dataclass(slots=True)
class _CacheEntry:
    value: set[str]
    expires_at: datetime


class RBACCache:
    def __init__(self, ttl_seconds: int = 300) -> None:
        self._ttl = ttl_seconds
        self._data: dict[str, _CacheEntry] = {}

    def get(self, key: str) -> set[str] | None:
        entry = self._data.get(key)
        if entry is None:
            return None
        if datetime.now(timezone.utc) >= entry.expires_at:
            self._data.pop(key, None)
            return None
        return set(entry.value)

    def set(self, key: str, value: set[str]) -> None:
        self._data[key] = _CacheEntry(
            value=set(value),
            expires_at=datetime.now(timezone.utc) + timedelta(seconds=self._ttl),
        )

    def invalidate(self, key: str | None = None) -> None:
        if key is None:
            self._data.clear()
            return
        self._data.pop(key, None)
