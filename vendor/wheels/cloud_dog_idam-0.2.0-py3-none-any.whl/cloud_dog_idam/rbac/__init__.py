# cloud_dog_idam — RBAC exports
"""RBAC engine, permission checker, and policy extension hooks."""

from cloud_dog_idam.rbac.engine import RBACEngine
from cloud_dog_idam.rbac.permissions import PermissionChecker
from cloud_dog_idam.rbac.policy_extensions import (
    authorise_with_extensions,
    clear_policy_evaluators,
    deregister_policy_evaluator,
    evaluate_policy_extensions,
    list_policy_evaluators,
    register_policy_evaluator,
)

__all__ = [
    "RBACEngine",
    "PermissionChecker",
    "authorise_with_extensions",
    "clear_policy_evaluators",
    "deregister_policy_evaluator",
    "evaluate_policy_extensions",
    "list_policy_evaluators",
    "register_policy_evaluator",
]
