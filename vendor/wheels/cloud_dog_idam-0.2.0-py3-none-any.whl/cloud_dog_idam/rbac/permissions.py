# cloud_dog_idam — Permission checker
"""Permission evaluation helpers for request-level authorisation."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PermissionChecker:
    permissions: set[str]
    user_id: str
    owned_groups: set[str]

    def has_permission(self, permission: str) -> bool:
        return permission in self.permissions or "*" in self.permissions

    def can_manage_group(self, group_id: str) -> bool:
        return self.has_permission("groups:manage") or group_id in self.owned_groups

    def can_access_resource(self, resource_owner_id: str) -> bool:
        return (
            self.has_permission("resources:read_any")
            or resource_owner_id == self.user_id
        )
