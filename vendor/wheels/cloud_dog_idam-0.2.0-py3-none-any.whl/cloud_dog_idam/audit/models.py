# cloud_dog_idam — Audit event models
"""Audit event schema definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass(slots=True)
class AuditEvent:
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    actor_id: str = ""
    action: str = ""
    target: str = ""
    outcome: str = "success"
    correlation_id: str = ""
    details: dict[str, Any] = field(default_factory=dict)
