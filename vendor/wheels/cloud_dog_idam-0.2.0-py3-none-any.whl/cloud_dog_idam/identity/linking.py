# cloud_dog_idam — Identity linking rules
"""Deterministic account-linking and conflict-resolution policies."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from cloud_dog_idam.audit.models import AuditEvent
from cloud_dog_idam.domain.models import IdentityLink


class LinkResolution(str, Enum):
    AUTO_LINK = "auto_link"
    ADMIN_APPROVAL = "admin_approval"
    REJECT = "reject"


@dataclass(slots=True)
class LinkDecision:
    resolution: LinkResolution
    reason: str


class IdentityLinkingPolicy:
    """Linking policy engine for email/subject/admin-approval strategies."""

    def can_auto_link(
        self, *, strategy: str, email_match: bool, subject_match: bool
    ) -> bool:
        if strategy == "email":
            return email_match
        if strategy == "subject":
            return subject_match
        return False

    def resolve_link_conflict(
        self,
        *,
        strategy: str,
        existing_links: list[IdentityLink],
        incoming_provider: str,
        incoming_subject: str,
        email_match: bool,
        subject_match: bool,
    ) -> LinkDecision:
        if any(
            link.provider_id == incoming_provider and link.subject == incoming_subject
            for link in existing_links
        ):
            return LinkDecision(
                LinkResolution.AUTO_LINK, "Exact provider-subject match"
            )

        if strategy == "admin_approval":
            return LinkDecision(
                LinkResolution.ADMIN_APPROVAL, "Policy requires explicit admin approval"
            )

        if self.can_auto_link(
            strategy=strategy, email_match=email_match, subject_match=subject_match
        ):
            return LinkDecision(LinkResolution.AUTO_LINK, "Auto-link policy matched")

        if existing_links:
            return LinkDecision(
                LinkResolution.ADMIN_APPROVAL,
                "Existing link conflict requires approval",
            )
        return LinkDecision(LinkResolution.REJECT, "No linking strategy matched")

    def create_audit_event(
        self,
        *,
        actor_id: str,
        action: str,
        target_identity_id: str,
        outcome: str,
        correlation_id: str,
        details: dict | None = None,
    ) -> AuditEvent:
        return AuditEvent(
            actor_id=actor_id,
            action=action,
            target=target_identity_id,
            outcome=outcome,
            correlation_id=correlation_id,
            details=details or {},
        )


def can_auto_link(*, strategy: str, email_match: bool, subject_match: bool) -> bool:
    return IdentityLinkingPolicy().can_auto_link(
        strategy=strategy,
        email_match=email_match,
        subject_match=subject_match,
    )
