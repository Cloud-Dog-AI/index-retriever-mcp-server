# cloud_dog_idam — Approval workflow service
"""Approval workflow handling for pending user activation and rejection."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from cloud_dog_idam.domain.enums import UserStatus
from cloud_dog_idam.domain.models import User


@dataclass(slots=True)
class ApprovalRecord:
    user_id: str
    approver_id: str
    action: str
    reason: str
    timestamp: datetime


class ApprovalService:
    def __init__(self, *, approval_ttl_seconds: int = 86_400) -> None:
        self._history: list[ApprovalRecord] = []
        self._pending_since: dict[str, datetime] = {}
        self._ttl = approval_ttl_seconds

    def mark_pending(self, user: User) -> User:
        user.status = UserStatus.PENDING_APPROVAL
        self._pending_since[user.user_id] = datetime.now(timezone.utc)
        return user

    def approve(
        self, user: User, *, approver_id: str = "system", role: str = "user"
    ) -> User:
        user.status = UserStatus.ACTIVE
        user.role = role
        self._pending_since.pop(user.user_id, None)
        self._history.append(
            ApprovalRecord(
                user.user_id, approver_id, "approve", "", datetime.now(timezone.utc)
            )
        )
        return user

    def reject(self, user: User, *, approver_id: str, reason: str) -> User:
        user.status = UserStatus.DISABLED
        self._pending_since.pop(user.user_id, None)
        self._history.append(
            ApprovalRecord(
                user.user_id, approver_id, "reject", reason, datetime.now(timezone.utc)
            )
        )
        return user

    def get_pending_approvals(self, users: list[User]) -> list[User]:
        return [u for u in users if u.status == UserStatus.PENDING_APPROVAL]

    def get_approval_history(self, user_id: str) -> list[ApprovalRecord]:
        return [r for r in self._history if r.user_id == user_id]

    def expire_pending(self, users: list[User]) -> int:
        now = datetime.now(timezone.utc)
        expired = 0
        for user in users:
            if user.status != UserStatus.PENDING_APPROVAL:
                continue
            since = self._pending_since.get(user.user_id)
            if since and now - since > timedelta(seconds=self._ttl):
                user.status = UserStatus.DISABLED
                expired += 1
        return expired
