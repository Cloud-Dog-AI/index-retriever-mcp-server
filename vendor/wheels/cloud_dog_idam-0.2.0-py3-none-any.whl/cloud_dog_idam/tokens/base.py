# cloud_dog_idam — Token service interface
"""Unified token service interface."""

from __future__ import annotations

from abc import ABC, abstractmethod

from cloud_dog_idam.domain.models import TokenPair


class TokenService(ABC):
    @abstractmethod
    def issue(self, user_id: str, claims: dict, ttl: int) -> TokenPair:
        raise NotImplementedError

    @abstractmethod
    def verify(self, token: str) -> dict:
        raise NotImplementedError

    @abstractmethod
    def revoke(self, token_id: str) -> None:
        raise NotImplementedError

    @abstractmethod
    def refresh(self, refresh_token: str) -> TokenPair:
        raise NotImplementedError
