# cloud_dog_idam — MFA/TOTP helpers
"""TOTP enrolment, verification, backup codes, and recovery helpers."""

from __future__ import annotations

import base64
import hashlib
import os
import secrets
from dataclasses import dataclass

try:
    import pyotp  # type: ignore
except ImportError:  # pragma: no cover
    pyotp = None


@dataclass(slots=True)
class MFASetup:
    secret: str
    otpauth_uri: str
    backup_codes: list[str]


def generate_totp_secret() -> str:
    if pyotp:
        return pyotp.random_base32()
    return base64.b32encode(os.urandom(20)).decode("ascii").rstrip("=")


def generate_backup_codes(count: int = 10) -> list[str]:
    return [secrets.token_hex(4) for _ in range(count)]


def hash_backup_code(code: str) -> str:
    return hashlib.sha256(code.encode("utf-8")).hexdigest()


def enrol_mfa(username: str, issuer: str = "cloud-dog") -> MFASetup:
    secret = generate_totp_secret()
    if pyotp:
        uri = pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name=issuer)
    else:
        uri = f"otpauth://totp/{issuer}:{username}?secret={secret}&issuer={issuer}"
    return MFASetup(
        secret=secret, otpauth_uri=uri, backup_codes=generate_backup_codes()
    )


def verify_totp(secret: str, code: str) -> bool:
    if pyotp is None:
        return False
    return bool(pyotp.TOTP(secret).verify(code, valid_window=1))


def consume_backup_code(backup_hashes: set[str], code: str) -> bool:
    hashed = hash_backup_code(code)
    if hashed not in backup_hashes:
        return False
    backup_hashes.remove(hashed)
    return True
