# cloud_dog_idam — Group service
"""Group CRUD and membership operations with optional repository backing."""

from __future__ import annotations

from typing import Protocol

from cloud_dog_idam.domain.models import Group


class GroupRepository(Protocol):
    def save(self, group: Group) -> Group: ...
    def list_all(self) -> list[Group]: ...
    def add_member(self, group_id: str, user_id: str) -> None: ...
    def members(self, group_id: str) -> set[str]: ...


class GroupService:
    def __init__(self, repository: GroupRepository | None = None) -> None:
        self._repo = repository
        self._groups: dict[str, Group] = {}
        self._members: dict[str, set[str]] = {}

    def create(self, group: Group) -> Group:
        if self._repo is not None:
            return self._repo.save(group)
        self._groups[group.group_id] = group
        self._members.setdefault(group.group_id, set())
        return group

    def add_member(self, group_id: str, user_id: str) -> None:
        if self._repo is not None and hasattr(self._repo, "add_member"):
            self._repo.add_member(group_id, user_id)
            return
        self._members.setdefault(group_id, set()).add(user_id)

    def members(self, group_id: str) -> set[str]:
        if self._repo is not None and hasattr(self._repo, "members"):
            return set(self._repo.members(group_id))
        return set(self._members.get(group_id, set()))

    def list(self) -> list[Group]:
        if self._repo is not None and hasattr(self._repo, "list_all"):
            return self._repo.list_all()
        return list(self._groups.values())
