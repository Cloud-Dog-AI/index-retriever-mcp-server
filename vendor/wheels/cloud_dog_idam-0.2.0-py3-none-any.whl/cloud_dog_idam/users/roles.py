# cloud_dog_idam — Role service
"""Role CRUD and assignment operations with optional repository backing."""

from __future__ import annotations

from typing import Protocol

from cloud_dog_idam.domain.models import Role


class RoleRepository(Protocol):
    def save(self, role: Role) -> Role: ...
    def list_all(self) -> list[Role]: ...
    def assign(self, user_id: str, role_name: str) -> None: ...
    def assigned(self, user_id: str) -> set[str]: ...


class RoleService:
    def __init__(self, repository: RoleRepository | None = None) -> None:
        self._repo = repository
        self._roles: dict[str, Role] = {}
        self._assignments: dict[str, set[str]] = {}

    def create(self, role: Role) -> Role:
        if self._repo is not None:
            return self._repo.save(role)
        self._roles[role.role_id] = role
        return role

    def assign(self, user_id: str, role_name: str) -> None:
        if self._repo is not None and hasattr(self._repo, "assign"):
            self._repo.assign(user_id, role_name)
            return
        self._assignments.setdefault(user_id, set()).add(role_name)

    def get_assigned(self, user_id: str) -> set[str]:
        if self._repo is not None and hasattr(self._repo, "assigned"):
            return set(self._repo.assigned(user_id))
        return set(self._assignments.get(user_id, set()))

    def list(self) -> list[Role]:
        if self._repo is not None and hasattr(self._repo, "list_all"):
            return self._repo.list_all()
        return list(self._roles.values())
