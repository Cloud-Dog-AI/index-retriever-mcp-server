# cloud_dog_logging — Size and time-based rotating file handler
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Configurable rotating file handler that combines size-based and
#   time-based rotation with retention policy. Rotation MUST NOT lose entries.
# Related requirements: FR1.7, FR1.8
# Related architecture: CC1.7

"""Size and time-based rotating file handler for cloud_dog_logging."""

from __future__ import annotations

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path


class ConfigurableRotatingHandler(RotatingFileHandler):
    """Rotating file handler with size-based rotation and retention policy.

    Combines size-based rotation with configurable backup count. Files are
    rotated when ``max_bytes`` is exceeded. Old files beyond ``backup_count``
    are removed.

    Rotation MUST NOT lose log entries — the handler flushes before rotating
    and uses atomic rename operations where supported.

    Args:
        filename: Path to the log file.
        max_bytes: Maximum file size in bytes before rotation. Defaults to 10 MB.
        backup_count: Number of rotated files to keep. Defaults to 5.
        encoding: File encoding. Defaults to ``utf-8``.
        append_only: If True, the file is opened in append mode and rotation
            preserves existing content. Defaults to False. Set True for audit logs.

    Related tests: ST1.2_FileRotation, ST1.6_RotationNoLoss
    """

    def __init__(
        self,
        filename: str,
        max_bytes: int = 10_485_760,
        backup_count: int = 5,
        encoding: str = "utf-8",
        append_only: bool = False,
    ) -> None:
        # Ensure parent directory exists
        Path(filename).parent.mkdir(parents=True, exist_ok=True)

        self._append_only = append_only
        mode = "a"

        super().__init__(
            filename=filename,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding=encoding,
            mode=mode,
        )

    def shouldRollover(self, record: logging.LogRecord) -> int:
        """Check whether a rollover should occur.

        Args:
            record: The log record about to be emitted.

        Returns:
            1 if rollover should occur, 0 otherwise.
        """
        if self.maxBytes <= 0:
            return 0

        if self.stream is None:
            self.stream = self._open()

        # Flush to ensure accurate file size
        self.stream.flush()

        try:
            self.stream.seek(0, 2)
            current_size = self.stream.tell()
        except OSError:
            current_size = os.path.getsize(self.baseFilename) if os.path.exists(self.baseFilename) else 0

        msg = self.format(record)
        if current_size + len(msg.encode(self.encoding or "utf-8")) + 1 >= self.maxBytes:
            return 1
        return 0

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a log record, performing rotation if necessary.

        Ensures no entries are lost during rotation by flushing before
        and after the write operation.

        Args:
            record: The log record to emit.
        """
        try:
            if self.shouldRollover(record):
                self.doRollover()
            logging.FileHandler.emit(self, record)
            if self.stream:
                self.stream.flush()
        except Exception:
            self.handleError(record)
