# cloud_dog_logging.sinks — File-backed audit sink
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: FileSink implementation writing append-only JSON Lines audit
#   events.
# Related requirements: FR1.18, FR1.14
# Related architecture: CC1.11

"""File sink implementation for audit events."""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import TextIO

from cloud_dog_logging.audit_schema import AuditEvent


class FileSink:
    """Append-only JSONL sink for audit events."""

    def __init__(self, path: str) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._stream: TextIO = self._path.open("a", encoding="utf-8")

    def emit(self, event: AuditEvent) -> None:
        payload = json.dumps(event.to_dict(), default=str, ensure_ascii=False)
        with self._lock:
            self._stream.write(payload + "\n")
            self._stream.flush()

    def flush(self) -> None:
        with self._lock:
            self._stream.flush()

    def close(self) -> None:
        with self._lock:
            self._stream.flush()
            self._stream.close()
