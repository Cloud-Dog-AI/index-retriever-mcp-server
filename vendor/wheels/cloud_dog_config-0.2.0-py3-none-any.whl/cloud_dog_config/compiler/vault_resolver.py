# cloud_dog_config — Vault resolver
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Resolves `vault.<project>.<path>` identifiers during compile phase
#   using a VaultClient-like interface.
# Related requirements: FR1.6, FR1.7
# Related architecture: CC1.5, CC1.6
#
# Recent changes:
# - 2026-02-15: Initial implementation.

"""Vault lookup resolver for the compile phase."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from cloud_dog_config.compiler.evaluator import Unresolved


class VaultReader(Protocol):
    """Protocol implemented by VaultClient and MockVaultClient."""

    def read(self, path: str) -> dict[str, Any] | str | None: ...


@dataclass(frozen=True, slots=True)
class VaultBundle:
    """Represents a Vault object/bundle result used for deep-merge assignment."""

    data: dict[str, Any]


def resolve_vault_identifier(identifier: str, *, vault: VaultReader) -> Any:
    """Resolve a `vault.*` identifier to a scalar or bundle.

    Supported forms:
    - vault.<project>.<path>          -> scalar (or dict)
    - vault.<project>.<path>.*        -> bundle (dict), wrapped in VaultBundle
    """
    if not identifier.startswith("vault."):
        return Unresolved(identifier)

    is_bundle = identifier.endswith(".*")
    core = identifier[:-2] if is_bundle else identifier
    parts = core.split(".")
    if len(parts) < 3:
        return Unresolved(identifier)

    project = parts[1]
    secret_parts = parts[2:]
    # For kv secret paths, map dot segments to path segments.
    secret_path = "/".join(secret_parts)

    # Read from secret/<project>/<path>
    vault_path = f"secret/{project}/{secret_path}"
    data = vault.read(vault_path)
    if data is None:
        return Unresolved(identifier)

    # If caller requested a bundle, require object.
    if is_bundle:
        if isinstance(data, dict):
            return VaultBundle(data=data)
        return Unresolved(identifier)

    # Scalar lookup:
    if isinstance(data, dict):
        # If the secret is an object, attempt to return the last key's value if present,
        # otherwise return the object.
        leaf = secret_parts[-1]
        if leaf in data:
            return data[leaf]
        return data

    return data
