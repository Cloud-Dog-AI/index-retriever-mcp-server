# cloud_dog_config — Circular reference detection
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Detects circular config reference chains during compile.
# Related requirements: FR1.9
# Related architecture: CC1.5
#
# Recent changes:
# - 2026-02-15: Initial implementation.

"""Circular reference detection utilities."""

from __future__ import annotations

from dataclasses import dataclass, field

from cloud_dog_config.errors import CircularReferenceError


@dataclass
class CircularDetector:
    """Tracks active resolution stack to detect circular references."""

    stack: list[str] = field(default_factory=list)
    active: set[str] = field(default_factory=set)

    def enter(self, path: str) -> None:
        if path in self.active:
            cycle = " -> ".join(self.stack + [path])
            raise CircularReferenceError(f"Circular reference detected: {cycle}")
        self.active.add(path)
        self.stack.append(path)

    def exit(self, path: str) -> None:
        if self.stack and self.stack[-1] == path:
            self.stack.pop()
        self.active.discard(path)
