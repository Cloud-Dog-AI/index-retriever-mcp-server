# cloud_dog_config — CLI helpers
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Helpers for working with `--env` style arguments in services and
#   tests.
# Related requirements: FR1.2, FR1.17
# Related architecture: SA1
#
# Recent changes:
# - 2026-02-15: Initial implementation.

"""CLI helpers for cloud_dog_config."""

from __future__ import annotations


def normalise_env_files(env_files: list[str] | None) -> list[str]:
    """Normalise env file arguments into a concrete list."""
    if not env_files:
        return []
    out: list[str] = []
    for item in env_files:
        if not item:
            continue
        out.extend([p.strip() for p in item.split(",") if p.strip()])
    return out
