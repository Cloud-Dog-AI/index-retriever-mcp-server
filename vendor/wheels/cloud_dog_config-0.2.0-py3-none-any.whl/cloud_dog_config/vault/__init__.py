# cloud_dog_config — Vault client interfaces
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Thin Vault client wrapper for config compilation.
# Related requirements: FR1.6
# Related architecture: CC1.6
#
# Recent changes:
# - 2026-02-15: Initial implementation.

"""Vault client wrappers for cloud_dog_config."""

from __future__ import annotations

from cloud_dog_config.vault.client import VaultClient
from cloud_dog_config.vault.mock_client import MockVaultClient

__all__ = ["MockVaultClient", "VaultClient"]
