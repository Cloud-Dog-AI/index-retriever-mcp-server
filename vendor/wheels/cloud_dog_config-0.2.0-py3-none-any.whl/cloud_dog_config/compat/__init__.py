# cloud_dog_config.compat — Compatibility exports
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Compatibility helpers for staged migration from legacy config
#   managers.
# Related requirements: FR1.21
# Related architecture: CC1.13
#
# Recent changes:
# - 2026-02-18: Added LegacyConfigAdapter export.

"""Compatibility helpers for cloud_dog_config."""

from __future__ import annotations

from cloud_dog_config.compat.legacy_adapter import LegacyConfigAdapter

__all__ = ["LegacyConfigAdapter"]
