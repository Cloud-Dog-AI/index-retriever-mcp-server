# cloud_dog_config — Public API
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: PS-80 configuration loader implementing canonical precedence,
#   compile-time placeholder resolution (refs, Vault, safe expressions),
#   schema validation, and an immutable GlobalConfig snapshot.
# Related requirements: SV1.1, SV1.2, FR1.1, FR1.4, FR1.11
# Related architecture: SA1, CC1.1, CC1.7
#
# Recent changes:
# - 2026-02-18: Added metadata, legacy adapter, profiles, bind, diff, export APIs.
# - 2026-02-15: Initial implementation.

"""cloud_dog_config — PS-80 configuration loader for Cloud-Dog services."""

from __future__ import annotations

from cloud_dog_config.bind import bind_model
from cloud_dog_config.compat import LegacyConfigAdapter
from cloud_dog_config.config import GlobalConfig
from cloud_dog_config.diff import ConfigChange, config_diff
from cloud_dog_config.export import export_config
from cloud_dog_config.loader import get_config, load_config, reload_config
from cloud_dog_config.metadata import EnvMetadata, get_env_metadata
from cloud_dog_config.profiles import resolve_profile

__all__ = [
    "ConfigChange",
    "EnvMetadata",
    "GlobalConfig",
    "LegacyConfigAdapter",
    "bind_model",
    "config_diff",
    "export_config",
    "get_env_metadata",
    "get_config",
    "load_config",
    "reload_config",
    "resolve_profile",
]
