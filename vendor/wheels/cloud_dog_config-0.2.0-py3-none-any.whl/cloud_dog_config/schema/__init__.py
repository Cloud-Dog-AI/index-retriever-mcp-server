# cloud_dog_config — Schema validation and secret scanning
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Optional schema validation and defaults.yaml secret scanning.
# Related requirements: FR1.12, FR1.18
# Related architecture: SA1
#
# Recent changes:
# - 2026-02-15: Initial implementation.

"""Schema and secret scanning helpers for cloud_dog_config."""

from __future__ import annotations

from cloud_dog_config.schema.secret_scanner import scan_for_secrets
from cloud_dog_config.schema.validator import validate_schema

__all__ = ["scan_for_secrets", "validate_schema"]
