# Copyright 2026 Cloud-Dog, Viewdeck Engineering Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# cloud_dog_llm — Timeout compatibility module
"""Compatibility wrapper for timeout helpers."""

from __future__ import annotations

from collections.abc import Awaitable
from typing import TypeVar

from cloud_dog_llm.runtime.timeouts import with_timeout

T = TypeVar("T")


async def apply_timeout(coro: Awaitable[T], timeout_seconds: float) -> T:
    """Handle apply timeout."""
    return await with_timeout(coro, timeout_seconds)
