# cloud_dog_logging.sinks — Database-backed audit sink
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: DatabaseSink implementation persisting audit events through a
#   repository protocol.
# Related requirements: FR1.18
# Related architecture: CC1.11

"""Database sink implementation for audit events."""

from __future__ import annotations

from cloud_dog_logging.audit_schema import AuditEvent
from cloud_dog_logging.sinks.base import AuditRepository


class DatabaseSink:
    """Persist audit events to a database via repository protocol."""

    def __init__(self, repository: AuditRepository | None = None) -> None:
        if repository is None:
            raise ImportError(
                "DatabaseSink requires a repository implementation. "
                "Provide an object implementing insert_event(event_dict)."
            )
        self._repository = repository

    def emit(self, event: AuditEvent) -> None:
        self._repository.insert_event(event.to_dict())

    def emit_batch(self, events: list[AuditEvent]) -> None:
        serialised = [event.to_dict() for event in events]
        insert_many = getattr(self._repository, "insert_events", None)
        if callable(insert_many):
            insert_many(serialised)
            return
        for payload in serialised:
            self._repository.insert_event(payload)

    def flush(self) -> None:
        flush_fn = getattr(self._repository, "flush", None)
        if callable(flush_fn):
            flush_fn()

    def close(self) -> None:
        close_fn = getattr(self._repository, "close", None)
        if callable(close_fn):
            close_fn()
