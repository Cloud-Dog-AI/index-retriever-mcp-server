# cloud_dog_logging.sinks — Audit sink protocol
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Protocol definitions for pluggable audit persistence sinks.
# Related requirements: FR1.18
# Related architecture: CC1.11

"""Base sink protocols for cloud_dog_logging audit events."""

from __future__ import annotations

from typing import Any, Protocol

from cloud_dog_logging.audit_schema import AuditEvent


class AuditSink(Protocol):
    """Protocol for audit event persistence sinks."""

    def emit(self, event: AuditEvent) -> None:
        """Persist one audit event."""

    def flush(self) -> None:
        """Flush buffered sink state."""

    def close(self) -> None:
        """Close sink resources."""


class AuditRepository(Protocol):
    """Repository protocol used by DatabaseSink."""

    def insert_event(self, event: dict[str, Any]) -> None:
        """Persist one serialised audit event."""

    def insert_events(self, events: list[dict[str, Any]]) -> None:
        """Persist multiple serialised audit events."""
