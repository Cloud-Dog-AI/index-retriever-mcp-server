# cloud_dog_logging.sinks — Sink exports
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Public exports for pluggable audit sink interfaces and
#   implementations.
# Related requirements: FR1.18
# Related architecture: CC1.11

"""Audit sink public API."""

from __future__ import annotations

from cloud_dog_logging.sinks.base import AuditRepository, AuditSink
from cloud_dog_logging.sinks.db_sink import DatabaseSink
from cloud_dog_logging.sinks.fan_out import FanOutSink
from cloud_dog_logging.sinks.file_sink import FileSink
from cloud_dog_logging.sinks.stdout_sink import StdoutSink

__all__ = [
    "AuditRepository",
    "AuditSink",
    "DatabaseSink",
    "FanOutSink",
    "FileSink",
    "StdoutSink",
]
