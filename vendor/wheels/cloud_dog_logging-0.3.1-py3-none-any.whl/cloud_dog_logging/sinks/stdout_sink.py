# cloud_dog_logging.sinks — Stdout audit sink
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: StdoutSink implementation writing JSON audit events to stdout.
# Related requirements: FR1.18
# Related architecture: CC1.11

"""Stdout sink implementation for audit events."""

from __future__ import annotations

import json
import sys
import threading
from typing import TextIO

from cloud_dog_logging.audit_schema import AuditEvent


class StdoutSink:
    """Write audit events to stdout as JSON lines."""

    def __init__(self, stream: TextIO | None = None) -> None:
        self._stream = stream or sys.stdout
        self._lock = threading.Lock()

    def emit(self, event: AuditEvent) -> None:
        payload = json.dumps(event.to_dict(), default=str, ensure_ascii=False)
        with self._lock:
            self._stream.write(payload + "\n")
            self._stream.flush()

    def flush(self) -> None:
        with self._lock:
            self._stream.flush()

    def close(self) -> None:
        self.flush()
