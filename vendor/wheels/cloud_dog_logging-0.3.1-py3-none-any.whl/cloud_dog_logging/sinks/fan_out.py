# cloud_dog_logging.sinks — Fan-out audit sink
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: FanOutSink dispatching audit events to multiple sinks.
# Related requirements: FR1.18
# Related architecture: CC1.11

"""Fan-out sink implementation for audit events."""

from __future__ import annotations

import logging

from cloud_dog_logging.audit_schema import AuditEvent
from cloud_dog_logging.sinks.base import AuditSink

_LOGGER = logging.getLogger("cloud_dog_logging.sinks.fan_out")


class FanOutSink:
    """Dispatch each event to multiple sinks."""

    def __init__(self, sinks: list[AuditSink]) -> None:
        if not sinks:
            raise ValueError("FanOutSink requires at least one sink")
        self._sinks = list(sinks)

    def emit(self, event: AuditEvent) -> None:
        for sink in self._sinks:
            try:
                sink.emit(event)
            except Exception as exc:  # noqa: BLE001
                _LOGGER.warning("Audit sink emit failed: %s", exc, extra={"sink": sink.__class__.__name__})

    def flush(self) -> None:
        for sink in self._sinks:
            try:
                sink.flush()
            except Exception as exc:  # noqa: BLE001
                _LOGGER.warning("Audit sink flush failed: %s", exc, extra={"sink": sink.__class__.__name__})

    def close(self) -> None:
        for sink in self._sinks:
            try:
                sink.close()
            except Exception as exc:  # noqa: BLE001
                _LOGGER.warning("Audit sink close failed: %s", exc, extra={"sink": sink.__class__.__name__})
