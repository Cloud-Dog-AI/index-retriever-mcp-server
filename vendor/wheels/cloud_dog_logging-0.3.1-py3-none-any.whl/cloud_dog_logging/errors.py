# cloud_dog_logging — Logging-specific exceptions
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Custom exception classes for the logging package.
# Related requirements: FR1.1, FR1.2
# Related architecture: SA1

"""Logging-specific exceptions for cloud_dog_logging."""


class LoggingConfigError(Exception):
    """Raised when logging configuration is invalid or incomplete."""


class AuditEventError(Exception):
    """Raised when an audit event fails validation."""


class RedactionError(Exception):
    """Raised when redaction processing encounters an error."""
