# cloud_dog_logging — Health package
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Health and observability reporting for the logging subsystem.
# Related architecture: SA1

"""Health reporting for cloud_dog_logging."""

from cloud_dog_logging.health.reporter import LogHealthReporter

__all__ = ["LogHealthReporter"]
