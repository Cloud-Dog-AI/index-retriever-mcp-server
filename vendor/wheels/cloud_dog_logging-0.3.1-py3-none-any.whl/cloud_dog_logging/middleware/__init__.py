# cloud_dog_logging — Middleware package
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: FastAPI middleware for request logging and correlation ID.
# Related architecture: SA1

"""FastAPI middleware for cloud_dog_logging."""

from cloud_dog_logging.middleware.fastapi import LoggingMiddleware

__all__ = ["LoggingMiddleware"]
