# cloud_dog_api_kit — Versioning helpers
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: API versioning helpers, including X-API-Version response header
#   middleware.
# Related requirements: FR10.4
# Related architecture: SA1, CC1.17

"""Versioning helpers for cloud_dog_api_kit."""

from __future__ import annotations

from cloud_dog_api_kit.versioning.header import VersionHeaderMiddleware

__all__ = ["VersionHeaderMiddleware"]
