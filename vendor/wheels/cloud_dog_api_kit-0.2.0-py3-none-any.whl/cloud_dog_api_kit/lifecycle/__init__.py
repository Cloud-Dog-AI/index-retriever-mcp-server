# cloud_dog_api_kit — Lifecycle integration exports
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Public lifecycle and graceful shutdown exports.
# Related requirements: FR18.2, FR18.9
# Related architecture: SA1

"""Lifecycle exports for cloud_dog_api_kit."""

from __future__ import annotations

from cloud_dog_api_kit.lifecycle.hooks import LifecycleHooks
from cloud_dog_api_kit.lifecycle.shutdown import (
    GracefulShutdownManager,
    ShutdownDrainMiddleware,
    install_shutdown_signal_handlers,
)

__all__ = [
    "GracefulShutdownManager",
    "LifecycleHooks",
    "ShutdownDrainMiddleware",
    "install_shutdown_signal_handlers",
]
