# cloud_dog_api_kit — Envelope schema re-exports
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Convenience re-exports for response envelope models.
# Related requirements: FR1.1, FR1.2
# Related architecture: SA1

"""Convenience re-exports for envelope models."""

from __future__ import annotations

from cloud_dog_api_kit.envelopes.error import ErrorDetail, ErrorResponse, error_envelope
from cloud_dog_api_kit.envelopes.success import Meta, SuccessResponse, success_envelope

__all__ = [
    "ErrorDetail",
    "ErrorResponse",
    "Meta",
    "SuccessResponse",
    "error_envelope",
    "success_envelope",
]
