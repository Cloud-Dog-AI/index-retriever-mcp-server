# cloud_dog_api_kit — Correlation ID context and middleware
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Context-local correlation ID, app ID, and host ID management
#   with ASGI middleware for automatic extraction/propagation.
# Related requirements: FR5.1, FR3.2
# Related architecture: CC1.8

"""Correlation ID context and middleware for cloud_dog_api_kit."""

from cloud_dog_api_kit.correlation.context import (
    get_app_id,
    get_correlation_id,
    get_host_id,
    get_request_id,
    set_app_id,
    set_correlation_id,
    set_host_id,
    set_request_id,
    clear_context,
)
from cloud_dog_api_kit.correlation.middleware import CorrelationMiddleware

__all__ = [
    "get_app_id",
    "get_correlation_id",
    "get_host_id",
    "get_request_id",
    "set_app_id",
    "set_correlation_id",
    "set_host_id",
    "set_request_id",
    "clear_context",
    "CorrelationMiddleware",
]
