# cloud_dog_api_kit — OpenAPI customisation helpers
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Helpers for OpenAPI schema customisation and versioning.
# Related requirements: FR10.1, FR10.2, FR10.4
# Related architecture: CC1.17

"""OpenAPI customisation helpers for cloud_dog_api_kit."""

from __future__ import annotations

from cloud_dog_api_kit.openapi.customise import configure_openapi
from cloud_dog_api_kit.openapi.route import create_openapi_router

__all__ = ["configure_openapi", "create_openapi_router"]
