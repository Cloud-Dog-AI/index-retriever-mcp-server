# cloud_dog_api_kit — OpenAPI spec route helper
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Provides a helper for serving an OpenAPI schema via a stable
#   endpoint.
# Related requirements: FR10.1
# Related architecture: SA1

"""OpenAPI spec route helper for cloud_dog_api_kit."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, FastAPI


def create_openapi_router(
    app: FastAPI,
    path: str = "/openapi.json",
    tags: list[str] | None = None,
) -> APIRouter:
    """Create a router that serves the OpenAPI schema for the given app."""
    router = APIRouter(tags=tags or ["openapi"])

    @router.get(path)
    async def openapi_schema() -> dict[str, Any]:
        return app.openapi()

    return router
