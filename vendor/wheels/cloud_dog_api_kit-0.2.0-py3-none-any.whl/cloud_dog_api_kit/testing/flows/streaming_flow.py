# cloud_dog_api_kit — Streaming flow template
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Reusable streaming flow checks for SSE/JSONL endpoints.
# Related requirements: FR8.1
# Related architecture: SA1

"""Streaming flow template for tests."""

from __future__ import annotations

from dataclasses import dataclass

import httpx


@dataclass(frozen=True, slots=True)
class StreamingFlow:
    """Reusable streaming flow assertions."""

    path: str

    async def fetch_stream(self, client: httpx.AsyncClient) -> str:
        r = await client.get(self.path)
        r.raise_for_status()
        return r.text
