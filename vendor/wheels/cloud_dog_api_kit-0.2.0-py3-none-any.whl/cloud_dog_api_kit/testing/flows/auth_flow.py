# cloud_dog_api_kit — Auth flow template
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Reusable auth flow checks for services using cloud_dog_api_kit.
# Related requirements: FR3.1, FR3.4
# Related architecture: SA1

"""Auth flow template for tests."""

from __future__ import annotations

from dataclasses import dataclass

import httpx


@dataclass(frozen=True, slots=True)
class AuthFlow:
    """Reusable auth flow assertions."""

    protected_path: str

    async def assert_unauthenticated(self, client: httpx.AsyncClient) -> None:
        r = await client.get(self.protected_path)
        assert r.status_code == 401
