# cloud_dog_api_kit — CRUD flow template
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Reusable CRUD flow checks for services using cloud_dog_api_kit.
# Related requirements: FR4.2
# Related architecture: SA1

"""CRUD flow template for tests."""

from __future__ import annotations

from dataclasses import dataclass

import httpx


@dataclass(frozen=True, slots=True)
class CRUDFlow:
    """Reusable CRUD flow assertions.

    This template is intentionally minimal; services can extend it for resource-specific behaviour.
    """

    collection_path: str

    async def create_and_get(self, client: httpx.AsyncClient, payload: dict) -> dict:
        created = await client.post(self.collection_path, json=payload)
        created.raise_for_status()
        created_data = created.json()["data"]
        resource_id = created_data["id"]

        fetched = await client.get(f"{self.collection_path}/{resource_id}")
        fetched.raise_for_status()
        return fetched.json()["data"]
