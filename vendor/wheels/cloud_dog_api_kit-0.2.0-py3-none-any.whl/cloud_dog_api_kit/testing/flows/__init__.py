# cloud_dog_api_kit — Test flow templates
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Reusable test flow templates for auth, CRUD, jobs, and streaming.
# Related requirements: FR17.1
# Related architecture: SA1

"""Reusable flow templates for cloud_dog_api_kit testing."""

from __future__ import annotations

from cloud_dog_api_kit.testing.flows.auth_flow import AuthFlow
from cloud_dog_api_kit.testing.flows.crud_flow import CRUDFlow
from cloud_dog_api_kit.testing.flows.job_flow import JobFlow
from cloud_dog_api_kit.testing.flows.streaming_flow import StreamingFlow

__all__ = ["AuthFlow", "CRUDFlow", "JobFlow", "StreamingFlow"]
