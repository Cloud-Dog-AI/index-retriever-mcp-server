# cloud_dog_api_kit — Job flow template
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Reusable job submission flow checks.
# Related requirements: FR7.1
# Related architecture: SA1

"""Job flow template for tests."""

from __future__ import annotations

from dataclasses import dataclass

import httpx


@dataclass(frozen=True, slots=True)
class JobFlow:
    """Reusable job submission assertions."""

    submit_path: str

    async def submit(self, client: httpx.AsyncClient, payload: dict) -> str:
        r = await client.post(self.submit_path, json=payload)
        r.raise_for_status()
        return r.json()["data"]["job_id"]
