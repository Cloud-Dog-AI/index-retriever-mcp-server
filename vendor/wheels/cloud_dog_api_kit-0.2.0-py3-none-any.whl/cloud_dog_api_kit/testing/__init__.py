# cloud_dog_api_kit — Test scaffolding (fixtures, conformance, flow templates)
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Reusable test fixtures, conformance validators, and baseline
#   flow templates for verifying API compliance.
# Related requirements: FR16.1, FR16.2, FR16.3
# Related architecture: CC1.19

"""Test scaffolding for cloud_dog_api_kit."""

from cloud_dog_api_kit.testing.fixtures import create_test_client, create_auth_headers
from cloud_dog_api_kit.testing.conformance import (
    validate_error_envelope,
    validate_success_envelope,
    validate_pagination_response,
    validate_correlation_id,
)
from cloud_dog_api_kit.testing.flows import AuthFlow, CRUDFlow, JobFlow, StreamingFlow

__all__ = [
    "create_test_client",
    "create_auth_headers",
    "validate_error_envelope",
    "validate_success_envelope",
    "validate_pagination_response",
    "validate_correlation_id",
    "AuthFlow",
    "CRUDFlow",
    "JobFlow",
    "StreamingFlow",
]
