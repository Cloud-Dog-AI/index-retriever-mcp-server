# cloud_dog_api_kit — Response envelopes
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Standard success and error response envelopes per PS-20.
# Related requirements: FR1.1, FR1.2
# Related architecture: CC1.1

"""Standard response envelopes for cloud_dog_api_kit."""

from __future__ import annotations

from cloud_dog_api_kit.envelopes.error import ErrorDetail, ErrorResponse, error_envelope
from cloud_dog_api_kit.envelopes.success import Meta, SuccessResponse, success_envelope

__all__ = [
    "ErrorDetail",
    "ErrorResponse",
    "Meta",
    "SuccessResponse",
    "success_envelope",
    "error_envelope",
]
