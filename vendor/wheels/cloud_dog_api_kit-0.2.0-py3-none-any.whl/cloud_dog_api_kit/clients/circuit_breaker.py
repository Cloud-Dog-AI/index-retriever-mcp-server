# cloud_dog_api_kit — Circuit breaker hook (optional)
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Optional circuit breaker hooks for HTTP client integrations.
# Related requirements: FR9.1
# Related architecture: SA1

"""Circuit breaker hooks for cloud_dog_api_kit."""

from __future__ import annotations

from typing import Protocol


class CircuitBreaker(Protocol):
    """Optional circuit breaker protocol."""

    def on_success(self) -> None: ...

    def on_failure(self) -> None: ...
