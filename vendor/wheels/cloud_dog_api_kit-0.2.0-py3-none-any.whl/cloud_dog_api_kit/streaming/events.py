# cloud_dog_api_kit — Streaming event models
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Standard SSE event model and serialisation.
# Related requirements: FR8.2
# Related architecture: SA1

"""Streaming event models for cloud_dog_api_kit."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any


@dataclass
class SSEEvent:
    """Standard server-sent event payload.

    Related tests: UT1.22_SSEEventModel
    """

    type: str
    data: Any = None
    request_id: str = ""
    job_id: str | None = None

    def to_sse(self) -> str:
        """Serialise to SSE wire format."""
        payload = {"type": self.type, "data": self.data, "request_id": self.request_id, "job_id": self.job_id}
        return f"event: {self.type}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"
