# cloud_dog_api_kit — Middleware components
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Standard middleware components (logging, CORS, timing, timeout).
# Related requirements: FR11.1, FR12.1, FR13.1
# Related architecture: SA1

"""Middleware components for cloud_dog_api_kit."""

from __future__ import annotations

from cloud_dog_api_kit.middleware.cors import configure_cors
from cloud_dog_api_kit.middleware.logging import RequestLoggingMiddleware
from cloud_dog_api_kit.middleware.request_size_limit import RequestSizeLimitMiddleware
from cloud_dog_api_kit.middleware.timing import TimingMiddleware
from cloud_dog_api_kit.middleware.timeout import TimeoutMiddleware

__all__ = [
    "RequestLoggingMiddleware",
    "RequestSizeLimitMiddleware",
    "TimingMiddleware",
    "TimeoutMiddleware",
    "configure_cors",
]
