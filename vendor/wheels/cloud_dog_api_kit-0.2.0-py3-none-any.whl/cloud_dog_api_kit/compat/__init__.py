# cloud_dog_api_kit — Compatibility and migration exports
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Migration compatibility middleware exports.
# Related requirements: FR18.3, FR18.4, FR18.6
# Related architecture: SA1

"""Compatibility middleware exports."""

from __future__ import annotations

from cloud_dog_api_kit.compat.envelope import LegacyEnvelopeMiddleware, legacy_envelope_route
from cloud_dog_api_kit.compat.profile import ProfileContextMiddleware
from cloud_dog_api_kit.compat.routes import LegacyRouteAdapter, LegacyRouteAdapterMiddleware

__all__ = [
    "LegacyEnvelopeMiddleware",
    "LegacyRouteAdapter",
    "LegacyRouteAdapterMiddleware",
    "ProfileContextMiddleware",
    "legacy_envelope_route",
]
