# cloud_dog_api_kit — A2A gateway
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: REST-to-A2A gateway helpers.
# Related requirements: FR15.1
# Related architecture: SA1

"""A2A gateway helpers for cloud_dog_api_kit."""

from __future__ import annotations

from cloud_dog_api_kit.a2a.gateway import A2AHandler, create_a2a_handler_from_endpoint

__all__ = ["A2AHandler", "create_a2a_handler_from_endpoint"]
