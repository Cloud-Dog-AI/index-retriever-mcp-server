# cloud_dog_api_kit — MCP gateway
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: REST-to-MCP gateway helpers.
# Related requirements: FR14.1
# Related architecture: SA1

"""MCP gateway helpers for cloud_dog_api_kit."""

from __future__ import annotations

from cloud_dog_api_kit.mcp.gateway import MCPToolDefinition, create_mcp_tool_from_endpoint
from cloud_dog_api_kit.mcp.contract import MCPContractRegistration, register_mcp_contract
from cloud_dog_api_kit.mcp.error_mapper import map_legacy_mcp_payload
from cloud_dog_api_kit.mcp.session import SESSION_HEADER, McpSession, McpSessionManager
from cloud_dog_api_kit.mcp.tool_router import ToolContract, register_tool_router
from cloud_dog_api_kit.mcp.transport import register_mcp_routes

__all__ = [
    "MCPContractRegistration",
    "MCPToolDefinition",
    "McpSession",
    "McpSessionManager",
    "SESSION_HEADER",
    "ToolContract",
    "create_mcp_tool_from_endpoint",
    "map_legacy_mcp_payload",
    "register_mcp_contract",
    "register_mcp_routes",
    "register_tool_router",
]
