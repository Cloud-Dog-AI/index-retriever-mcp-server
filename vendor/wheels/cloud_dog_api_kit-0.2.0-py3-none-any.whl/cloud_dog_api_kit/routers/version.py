# cloud_dog_api_kit — Version endpoint router
#
# Licence: Proprietary — Cloud-Dog AI Platform
# Owner: Cloud-Dog AI
# Description: Provides a standard `/api/v1/version` endpoint for services.
# Related requirements: FR10.3
# Related architecture: SA1

"""Version endpoint router."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter


def create_version_router(
    api_prefix: str,
    application_name: str,
    version: str,
    api_version: str = "v1",
) -> APIRouter:
    """Create a router exposing `/version` under the given API prefix."""
    router = APIRouter(prefix=api_prefix, tags=["system"])

    @router.get("/version")
    async def api_version_endpoint() -> dict[str, Any]:
        return {"application": application_name, "version": version, "api_version": api_version}

    return router
