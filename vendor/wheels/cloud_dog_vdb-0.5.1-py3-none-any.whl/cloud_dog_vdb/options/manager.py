# Copyright 2026 Cloud-Dog, Viewdeck Engineering Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from cloud_dog_vdb.options.chroma import chroma_options
from cloud_dog_vdb.options.opensearch import opensearch_options
from cloud_dog_vdb.options.pgvector import pgvector_options
from cloud_dog_vdb.options.qdrant import qdrant_options
from cloud_dog_vdb.options.weaviate import weaviate_options


def merge_options(store_type: str, overrides: dict | None = None) -> dict:
    """Handle merge options."""
    mapping = {
        "chroma": chroma_options,
        "qdrant": qdrant_options,
        "weaviate": weaviate_options,
        "opensearch": opensearch_options,
        "pgvector": pgvector_options,
    }
    fn = mapping.get(store_type, lambda ov: ov or {})
    return fn(overrides)
